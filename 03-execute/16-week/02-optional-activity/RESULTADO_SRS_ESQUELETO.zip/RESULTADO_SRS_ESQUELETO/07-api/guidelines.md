# Lineamientos de la API / Rutas Flask

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema usa Flask con renderizado de templates HTML (Jinja2). Las rutas siguen convenciones REST básicas adaptadas a una aplicación web tradicional.

## Convenciones de rutas

| Método | Patrón | Uso |
|--------|--------|-----|
| GET | `/recurso` | Listar o mostrar una vista |
| GET | `/recurso/<id>` | Ver detalle de un recurso |
| POST | `/recurso/nuevo` | Crear un recurso |
| POST | `/recurso/<id>/editar` | Actualizar un recurso |
| POST | `/recurso/<id>/eliminar` | Eliminar un recurso |

## Rutas principales del sistema

| Ruta | Método | Módulo | Rol requerido | RF |
|------|--------|--------|---------------|----|
| `/login` | GET, POST | Autenticación | Ninguno | RF-01 |
| `/logout` | GET | Autenticación | Cualquiera | RF-01 |
| `/ventas` | GET | Ventas | Cajero, Admin | RF-02, RF-08 |
| `/ventas/nueva` | GET, POST | Ventas | Cajero, Admin | RF-02, RF-03, RF-04 |
| `/productos` | GET | Productos | Administrador | RF-05 |
| `/productos/nuevo` | GET, POST | Productos | Administrador | RF-05 |
| `/productos/<id>/editar` | GET, POST | Productos | Administrador | RF-05 |
| `/productos/<id>/eliminar` | POST | Productos | Administrador | RF-05 |
| `/inventario` | GET | Inventario | Administrador | RF-06 |
| `/reportes` | GET | Reportes | Administrador | RF-07 |

## Respuestas y redirecciones

- Operación exitosa → redirige a la lista del módulo con mensaje flash de éxito.
- Error de validación → recarga el formulario con mensaje de error en español (RNF-04).
- Sin sesión activa → redirige a `/login`.
- Rol insuficiente → responde con error 403 y mensaje descriptivo.

## Referencias

- SRS La Esquina v1.0 — RF-01 a RF-08, Tabla 2 (Roles), RNF-04, RNF-05.
