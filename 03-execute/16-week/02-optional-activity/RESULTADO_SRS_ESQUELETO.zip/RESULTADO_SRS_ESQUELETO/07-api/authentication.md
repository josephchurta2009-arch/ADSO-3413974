# Autenticación

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema usa autenticación basada en sesiones de Flask. No se usa JWT ni OAuth para v1.0. El mecanismo es usuario + contraseña con hash.

## Flujo de autenticación

```
Usuario                 Flask (Backend)              SQLite
   │                         │                          │
   │── POST /login ──────────►│                          │
   │   {usuario, password}   │                          │
   │                         │── SELECT * FROM usuario ─►│
   │                         │   WHERE nombre_usuario=?  │
   │                         │◄─────────────────────────│
   │                         │   [registro del usuario]  │
   │                         │                          │
   │                         │ verify_password(hash)    │
   │                         │  → True/False            │
   │                         │                          │
   │◄─ Redirect /panel ──────│ (si OK: session[rol])   │
   │   o error en /login     │ (si falla: flash error)  │
```

## Rutas de autenticación

### GET/POST `/login`

- **GET:** Renderiza el formulario de inicio de sesión.
- **POST:** Valida credenciales.
  - Si correctas: almacena `session['usuario_id']` y `session['rol']`, redirige al panel.
  - Si incorrectas: muestra mensaje "Usuario o contraseña incorrectos".

### GET `/logout`

- Limpia la sesión activa y redirige a `/login`.

## Protección de rutas

```python
# Decorador para rutas que requieren sesión activa
@app.before_request
def verificar_sesion():
    rutas_publicas = ['login', 'static']
    if request.endpoint not in rutas_publicas:
        if 'usuario_id' not in session:
            return redirect(url_for('login'))

# Decorador para rutas solo de Administrador
def solo_admin(f):
    if session.get('rol') != 'ADMINISTRADOR':
        abort(403)
```

## Seguridad de contraseñas

```python
from werkzeug.security import generate_password_hash, check_password_hash

# Al crear usuario:
password_hash = generate_password_hash(password_plano)

# Al verificar login:
check_password_hash(password_hash, password_ingresado)
```

## Referencias

- SRS La Esquina v1.0 — RF-01, RNF-05, Tabla 2 (Perfiles de Usuario).
- [security-rules.md](../00-governance/security-rules.md)
