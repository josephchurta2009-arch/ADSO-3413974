# API

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta las rutas HTTP del backend Flask del sistema de gestión del supermercado "La Esquina".

> **Nota:** El sistema v1.0 es una aplicación web tradicional con Flask renderizando templates HTML (no una API REST pura). Las rutas son endpoints web que devuelven páginas renderizadas. Si en el futuro se agrega una API REST, sus contratos irán en `contracts/`.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [guidelines.md](./guidelines.md) | Convenciones de rutas y respuestas HTTP del sistema | 🟢 |
| [authentication.md](./authentication.md) | Rutas y flujo de autenticación | 🟢 |
| [contracts/](./contracts/) | Contratos de endpoints por módulo | 🟡 |
