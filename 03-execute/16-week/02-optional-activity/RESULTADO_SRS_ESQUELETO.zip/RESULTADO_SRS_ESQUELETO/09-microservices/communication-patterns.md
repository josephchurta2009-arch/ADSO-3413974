# Patrones de Comunicación

> Estado: ⚫ Deprecado (No aplica) | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Dado que la arquitectura es monolítica, no existen patrones de comunicación distribuida (como colas de mensajes, gRPC o APIs internas entre servicios). 

Toda comunicación entre módulos (ej. el módulo de ventas informando al de inventario que reduzca el stock) se realiza mediante llamadas directas a funciones o métodos dentro del mismo proceso de Python.
