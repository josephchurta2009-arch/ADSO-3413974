# Catálogo de Servicios

> Estado: ⚫ Deprecado (No aplica) | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema de gestión "La Esquina" es una aplicación monolítica. Todos los módulos (autenticación, ventas, productos, inventario, reportes) son partes lógicas dentro de la misma aplicación Flask y comparten la misma base de datos SQLite.

Por tanto, no existe un catálogo de microservicios.
