# Microservicios

> Estado: ⚫ Deprecado (No aplica) | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Este módulo de documentación está **deprecado para la versión 1.0** del sistema de gestión del supermercado "La Esquina".

Como se define en el **[ADR-002](../05-architecture/decisions/records/ADR-002-arquitectura-monolitica.md)**, el sistema sigue una **arquitectura web monolítica** de tres capas con Flask y SQLite, justificada por el tamaño del equipo (junior), el alcance del proyecto (MVP para un solo negocio local) y los requerimientos no funcionales (uso en computadores básicos locales).

Por tanto, no existen microservicios, catálogos de servicios ni patrones de comunicación distribuida. Todo se ejecuta en un único proceso de servidor Flask.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [service-catalog.md](./service-catalog.md) | Catálogo de microservicios | ⚫ N/A |
| [communication-patterns.md](./communication-patterns.md) | Patrones de comunicación (eventos, gRPC, REST) | ⚫ N/A |

## Referencias

- SRS La Esquina v1.0 — Tecnología y alcance.
- [05-architecture/overview.md](../05-architecture/overview.md)
