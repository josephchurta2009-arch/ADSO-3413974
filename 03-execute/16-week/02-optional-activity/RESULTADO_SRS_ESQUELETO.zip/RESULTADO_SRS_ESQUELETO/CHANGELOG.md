# Changelog

> Registro de todos los cambios notables en la documentación del proyecto "La Esquina".

## [1.0.0] - 2026-07-07

### Added
- Conversión inicial del documento PDF `SRS_LaEsquina_.pdf` al formato estandarizado de arquitectura de directorios.
- `01-context`: Definición del problema, objetivos, alcances y limitaciones funcionales.
- `02-domain`: Generación del mapa del dominio del supermercado y reglas de negocio.
- `03-product`: Backlog priorizado derivado de los RF-01 al RF-08.
- `04-requirements`: Desglose detallado de todos los requisitos funcionales, historias de usuario con criterios de aceptación y la matriz de trazabilidad.
- `05-architecture` y `06-data`: Definición del stack tecnológico a utilizar (Flask + SQLite) en ADR-001 y establecimiento del diagrama ER y diccionario de datos.
- `09-microservices`: Se deprecó formalmente la carpeta al ratificar la arquitectura monolítica.
- `10-devops` a `15-project-control`: Guías técnicas, reglas de calidad, manuales para administrador y cajero, riesgos operativos.
- Archivos raíz y carpetas complementarias (`assets`, `99-archive`) inicializados.
