# Guía de contribución

Este repositorio es la fuente de verdad documental del proyecto **Sistema de Gestión Supermercado "La Esquina"**. Todo estudiante del equipo ADSO SENA que trabaje en el proyecto documenta aquí, siguiendo las reglas de gobierno documental.

## Regla de oro

No trabajar directamente sobre `main` o `develop`. Todo cambio debe hacerse en una rama nueva, pasar por revisión (Code Review) y aprobación de al menos un compañero del equipo.

## Estructura general

| Sección | Propósito |
|---------|-----------|
| `00-governance/` | Reglas del repositorio documental |
| `01-context/` | Contexto, alcance y glosario del supermercado |
| `02-domain/` | Entidades y reglas de negocio (Ventas, Stock) |
| `03-product/` | Visión, roadmap (v1.0/v2.0) y backlog |
| `04-requirements/` | Requisitos funcionales, historias y trazabilidad |
| `05-architecture/` | Stack (Flask, SQLite) y decisiones (ADR) |
| `06-data/` | Diccionario de SQLite y modelo relacional |
| `07-api/` | Guidelines web y flujos de login |
| `08-uml/` | Índice de diagramas |
| `09-microservices/` | ⚫ Deprecado (es monolito) |
| `10-devops/` | Guías de Setup para estudiantes |
| `11-quality/` | Testing manual y revisión de código |
| `12-ux-ui/` | Bootstrap y wireframes |
| `13-operations/` | Backups (USB) y soporte en el negocio |
| `14-training/` | Manuales para el cliente (Propietario/Cajero) |
| `15-project-control/` | Deuda técnica y riesgos |
| `99-archive/` | Documentos deprecados |
| `assets/` | Elementos gráficos e imágenes estáticas |

## Flujo rápido para editar documentación

1. Identifica la sección correcta según la tabla.
2. Revisa [documentation-rules.md](./00-governance/documentation-rules.md).
3. Crea una rama según convenciones (`feat/nueva-funcion`).
4. Edita o crea el documento con el estado `🔴 Pendiente` o `🟡 En progreso`.
5. Si es nuevo, añade el enlace en el `README.md` de su respectiva carpeta.
6. Haz commit descriptivo, abre Pull Request y solicita revisión a tu equipo ADSO.

## Antes de abrir PR

- [ ] El documento cumple la [Definition of Ready](./00-governance/definition-of-ready.md).
- [ ] No se publican contraseñas de correos, bases de datos o secretos de Flask.
- [ ] Si se tomó una decisión grande, se escribió un ADR en `05-architecture`.
