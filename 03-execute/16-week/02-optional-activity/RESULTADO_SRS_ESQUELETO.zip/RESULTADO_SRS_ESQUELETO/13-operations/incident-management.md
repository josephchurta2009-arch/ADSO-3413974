# Gestión de Incidentes

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Procedimiento básico para atender fallos o errores reportados por los usuarios (Administrador o Cajero) del supermercado "La Esquina".

## Niveles de Soporte (v1.0)

El proyecto es entregado como un proyecto formativo del SENA. El soporte estará a cargo del equipo de estudiantes durante el tiempo que dure la fase práctica.

## Tipos de Incidentes Comunes

### 1. El sistema no abre en el navegador
- **Causa probable:** El servidor local (Flask) está apagado o se cerró accidentalmente.
- **Solución:** Volver a ejecutar el comando de inicio en la terminal (`flask run`).

### 2. Error 500 (Internal Server Error) al registrar venta
- **Causa probable:** Inconsistencia en la base de datos o fallo en el código.
- **Solución:** El desarrollador debe revisar el archivo `errores_sistema.log` para identificar la traza del error.

### 3. Olvido de contraseña del Administrador
- **Causa probable:** Error humano.
- **Solución:** Como no hay funcionalidad de "recuperar contraseña" por correo, un desarrollador debe acceder al computador, abrir una consola de Python y usar `werkzeug.security` para actualizar manualmente el hash en SQLite.
