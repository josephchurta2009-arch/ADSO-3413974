# Operaciones

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta los procedimientos operativos del sistema de gestión "La Esquina" en su entorno de producción (el computador local del supermercado).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [observability.md](./observability.md) | Monitoreo básico y logs | 🟢 |
| [backup-and-recovery.md](./backup-and-recovery.md) | Política de respaldos de la base de datos | 🟢 |
| [incident-management.md](./incident-management.md) | Gestión de incidentes y soporte básico | 🟢 |
