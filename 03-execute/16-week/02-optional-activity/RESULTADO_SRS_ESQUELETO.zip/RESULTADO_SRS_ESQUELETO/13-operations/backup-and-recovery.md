# Backup y Recuperación

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Al utilizar SQLite, toda la información (usuarios, productos, inventario, ventas) se almacena en un único archivo físico (`laesquina.db`). La pérdida o corrupción de este archivo significa la pérdida total de los datos del negocio.

## Política de Backup (Manual)

Se debe enseñar al Administrador del supermercado "La Esquina" a realizar un respaldo periódico:

1. **Frecuencia:** Al finalizar cada jornada laboral (diario).
2. **Procedimiento:**
   - Ubicar el archivo `laesquina.db` en la carpeta del sistema.
   - Copiar el archivo.
   - Pegarlo en una memoria USB externa dedicada para este fin, o subirlo a un servicio gratuito en la nube (como Google Drive o OneDrive personal).

## Recuperación ante Desastres

Si el computador del negocio sufre daños o se corrompe el archivo `.db`:

1. Reinstalar el sistema siguiendo la guía en `10-devops/local-setup.md`.
2. Reemplazar el archivo nuevo `laesquina.db` por la copia de seguridad más reciente de la memoria USB.
3. El sistema arrancará con los datos exactos del momento del respaldo.
