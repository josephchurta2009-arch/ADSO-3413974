# Observabilidad

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema se ejecuta localmente en el computador del negocio, por lo que no se requieren herramientas de observabilidad en la nube (como Datadog o New Relic).

## Logs del Sistema

- El framework Flask escribe sus logs en la consola local.
- Para producción, se debe configurar el módulo `logging` de Python para que guarde los errores en un archivo llamado `errores_sistema.log` dentro de la carpeta del proyecto.

```python
import logging
logging.basicConfig(filename='errores_sistema.log', level=logging.ERROR)
```

## Monitoreo Básico

El propio administrador de "La Esquina" actuará como monitor del sistema:
- Si la página no carga (Error de conexión), el servidor Flask se detuvo.
- Los errores de la aplicación mostrarán alertas en pantalla (ej: "Stock insuficiente").
