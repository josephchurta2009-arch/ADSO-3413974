# Configuración de Entorno Local

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Guía para que cualquier desarrollador del equipo (SENA ADSO) pueda configurar el proyecto localmente y comenzar a contribuir al Sistema de Gestión "La Esquina".

## Requisitos Previos

- **Git** instalado.
- **Python 3.10** o superior instalado y configurado en el PATH.
- Editor de código (se recomienda Visual Studio Code).
- Navegador web (Chrome o Firefox).

## Pasos de Instalación

1. **Clonar el repositorio:**
   ```bash
   git clone <url-del-repositorio>
   cd LaEsquina-Sistema
   ```

2. **Crear y activar un entorno virtual:**
   - Windows:
     ```bash
     python -m venv venv
     venv\Scripts\activate
     ```
   - Linux/Mac:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

3. **Instalar dependencias:**
   ```bash
   pip install -r requirements.txt
   ```
   *(El archivo incluirá `Flask`, `Flask-Login` u otras definidas por el equipo).*

4. **Inicializar la base de datos (SQLite):**
   ```bash
   python init_db.py
   ```
   Esto creará el archivo `laesquina.db` y el usuario administrador por defecto.

5. **Ejecutar el servidor local:**
   ```bash
   flask run
   # o
   python app.py
   ```
   El sistema estará disponible en `http://localhost:5000`.

## Referencias

- SRS La Esquina v1.0 — Tabla 1 (Pila Tecnológica).
