# Ambientes

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Dada la naturaleza del proyecto (sistema web local para un negocio pequeño) y el alcance (v1.0), se manejan únicamente dos ambientes.

## Ambientes Definidos

| Ambiente | Entorno Físico | Base de Datos | Propósito |
|----------|----------------|---------------|-----------|
| **Desarrollo** | Computador del desarrollador | `dev.db` (ficticia) | Escribir código, probar nuevas funcionalidades y realizar pruebas manuales |
| **Producción** | Computador del supermercado "La Esquina" | `laesquina.db` (real) | Uso operativo diario por el administrador y el cajero |

## Gestión de Configuración

En v1.0, las configuraciones no sensibles (puerto, modo debug) pueden estar en un archivo `.env` o en `config.py`.

- **Desarrollo:** `FLASK_DEBUG=1`, `DATABASE_URI=sqlite:///dev.db`
- **Producción:** `FLASK_DEBUG=0`, `DATABASE_URI=sqlite:///laesquina.db`, `SECRET_KEY` segura generada para las sesiones.

## Referencias

- SRS La Esquina v1.0 — RNF-03 (Ejecución en computadores básicos del negocio).
