# CI/CD y Despliegue

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema de gestión "La Esquina" en su v1.0 no utiliza plataformas de nube públicas (como AWS, Heroku o Render) ya que su ejecución es local en el negocio cliente (RNF-03). Por ello, el flujo de CI/CD es simplificado.

## Integración Continua (CI)

- **Repositorio central:** GitHub (según Tabla 1 del SRS).
- **Control de versiones:** Se sigue la convención de ramas y Pull Requests ([git-conventions.md](../00-governance/git-conventions.md)).
- **Validaciones:** Por ahora, la revisión de código (Code Review) actúa como puerta de calidad antes de hacer merge a `main`. No se han definido GitHub Actions automáticas, aunque podrían incorporarse en el futuro para verificar sintaxis de Python o HTML.

## Despliegue (CD - Manual)

El despliegue en producción (el computador del negocio) se realiza de forma manual:

1. El administrador de TI (o estudiante del SENA asignado) accede al equipo del supermercado.
2. Descarga la versión más reciente del código estable (rama `main`).
3. Instala/actualiza las dependencias de Python si las hay.
4. Reinicia el servidor Flask local.

## Referencias

- SRS La Esquina v1.0 — RNF-03, Tabla 1 (Git y GitHub).
