# DevOps

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta las prácticas de integración continua, despliegue, configuración de entornos y configuración del ambiente local para el desarrollo del sistema "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [local-setup.md](./local-setup.md) | Guía de configuración del entorno de desarrollo local | 🟢 |
| [environments.md](./environments.md) | Definición de los ambientes de ejecución | 🟢 |
| [ci-cd.md](./ci-cd.md) | Estrategia de integración continua y despliegue | 🟢 |
