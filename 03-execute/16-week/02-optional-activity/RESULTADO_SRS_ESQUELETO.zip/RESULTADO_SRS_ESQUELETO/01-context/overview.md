# Overview — Sistema de Gestión Supermercado "La Esquina"

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contexto institucional

Este proyecto es desarrollado por estudiantes del programa **Análisis y Desarrollo de Software Orientado (ADSO)** del **SENA** (Servicio Nacional de Aprendizaje), sede Neiva, Huila. Corresponde a un proyecto formativo de la versión 1.0, elaborado en 2025.

El cliente es el supermercado **"La Esquina"**, un negocio pequeño de barrio ubicado en **Neiva, Huila**, que atiende a la comunidad local y opera de manera completamente manual.

## Problema

El supermercado "La Esquina" presenta los siguientes problemas operativos que motivan el desarrollo del sistema:

- **Registro manual de ventas:** todas las ventas se registran en cuadernos y hojas de papel, lo que genera pérdida de información y dificulta el control.
- **Errores en cálculos y cierres de caja:** los cálculos manuales generan diferencias frecuentes al momento del cierre diario.
- **Falta de control del inventario:** no existe un mecanismo que refleje en tiempo real el stock disponible de cada producto.
- **Productos agotados sin aviso:** el negocio no cuenta con alertas que indiquen cuando un producto alcanza niveles críticos de existencia.
- **Demora al buscar precios:** la consulta de precios se hace manualmente revisando listas en papel, lo que ralentiza el proceso de atención al cliente.

## Objetivos

### Objetivo general

Desarrollar un sistema web sencillo que permita gestionar las operaciones principales del supermercado "La Esquina", digitalizando el registro de ventas y el control de inventario.

### Objetivos específicos

1. Registrar ventas de manera digital con cálculo automático del total.
2. Controlar el inventario en tiempo real, actualizándolo tras cada venta.
3. Gestionar el catálogo de productos (agregar, editar, eliminar).
4. Administrar los usuarios del sistema con roles diferenciados.
5. Generar reportes básicos de ventas (diarios y por fecha).
6. Emitir alertas automáticas cuando el stock de un producto sea bajo.

## Referencias

- SRS Sistema de Gestión Supermercado "La Esquina" v1.0, 2025 — Secciones: Introducción, Descripción del Negocio, Problema Actual, Objetivo del Sistema.
