# Contexto

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contenido

Describe el problema de negocio, el alcance del sistema, el contexto institucional y el vocabulario base del proyecto **Sistema de Gestión Supermercado "La Esquina"**.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Contexto del negocio, problema actual y objetivos generales | 🟢 |
| [scope.md](./scope.md) | Alcance, exclusiones, supuestos y restricciones | 🟢 |
| [glossary.md](./glossary.md) | Glosario de términos del dominio del supermercado y del sistema | 🟢 |
