# Alcance

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## En alcance

Las siguientes funcionalidades están incluidas en la **versión 1.0** del sistema:

- Inicio de sesión con autenticación (usuario y contraseña).
- Roles diferenciados: **Administrador** y **Cajero**.
- Registro digital de ventas por parte del cajero.
- Cálculo automático del total de cada venta.
- Actualización automática del inventario tras cada venta.
- Gestión del catálogo de productos: agregar, editar y eliminar.
- Alertas de stock bajo para productos con existencias críticas.
- Historial de ventas almacenado en base de datos.
- Reportes básicos de ventas (por día y por fecha).

## Fuera de alcance

Las siguientes funcionalidades quedan **excluidas de la versión 1.0**:

- Facturación electrónica (DIAN).
- Integración con pasarelas de pagos bancarios.
- Aplicación móvil (Android / iOS).
- Gestión avanzada de proveedores.
- Soporte para múltiples sucursales.

## Supuestos

- El negocio cuenta con al menos un computador básico con navegador web moderno instalado.
- El sistema será usado en una red local o con acceso a internet básico.
- El equipo de desarrollo está conformado por estudiantes junior del programa ADSO.
- La base de datos SQLite es suficiente para el volumen de operaciones de un negocio pequeño de barrio.
- El propietario o encargado del negocio actuará como administrador del sistema.

## Restricciones

- El sistema debe desarrollarse con HTML, CSS, JavaScript, Python/Flask y SQLite (stack definido en el SRS).
- El tiempo de respuesta de las operaciones debe ser inferior a 2 segundos (RNF-02).
- La interfaz debe estar completamente en español (RNF-04).
- El sistema debe ser usable en computadores básicos del negocio (RNF-03).

## Referencias

- SRS La Esquina v1.0 — Sección "Alcance del Sistema": Funciones Incluidas y Funciones Fuera del Alcance.
