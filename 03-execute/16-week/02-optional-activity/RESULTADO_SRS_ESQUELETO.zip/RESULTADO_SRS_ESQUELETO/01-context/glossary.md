# Glosario

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contexto

Vocabulario base del dominio del supermercado "La Esquina" y del sistema de gestión asociado.

## Términos del dominio de negocio

| Término | Definición | Contexto |
|---------|------------|----------|
| Supermercado "La Esquina" | Negocio pequeño de barrio ubicado en Neiva, Huila, cliente del sistema | Negocio |
| Venta | Transacción donde un cajero registra uno o más productos vendidos a un cliente | Operación |
| Producto | Artículo disponible en el inventario del supermercado con nombre, código y precio | Inventario |
| Inventario | Conjunto de productos y sus existencias disponibles en el negocio | Operación |
| Stock | Cantidad disponible de un producto en inventario | Inventario |
| Stock bajo | Condición en que la existencia de un producto cae por debajo de un umbral mínimo | Alerta |
| Cierre de caja | Proceso diario de cuadre entre las ventas registradas y el dinero en caja | Operación |
| Reporte de ventas | Documento o vista que resume las ventas realizadas en un período de tiempo | Reportes |
| Catálogo de productos | Lista completa de productos gestionados en el sistema | Inventario |

## Términos del sistema

| Término | Definición | Contexto |
|---------|------------|----------|
| Administrador | Rol de usuario con acceso completo: gestión de productos, inventario, reportes y usuarios | Sistema |
| Cajero | Rol de usuario con acceso restringido al módulo de registro de ventas | Sistema |
| RF | Requerimiento Funcional — describe una capacidad que el sistema debe proveer | SRS |
| RNF | Requerimiento No Funcional — describe una restricción de calidad del sistema | SRS |
| CU | Caso de Uso — describe la interacción entre un actor y el sistema para lograr un objetivo | SRS |
| Flask | Framework web de Python utilizado para el backend del sistema | Tecnología |
| SQLite | Motor de base de datos relacional ligero usado para persistencia de datos | Tecnología |
| Bootstrap | Framework CSS utilizado para el diseño de la interfaz de usuario | Tecnología |
| SRS | Especificación de Requerimientos de Software — documento base de este proyecto | Documento |
| ADSO | Análisis y Desarrollo de Software Orientado — programa del SENA | Institución |
| SENA | Servicio Nacional de Aprendizaje — institución educativa colombiana | Institución |

## Referencias

- SRS Sistema de Gestión Supermercado "La Esquina" v1.0, 2025 — Resumen, Introducción, Tablas 1-4.
