# Archivo (Archive)

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Esta sección funciona como un "cementerio de documentos". Almacena archivos que formaron parte del proyecto "La Esquina" en el pasado pero que ya no están vigentes, evitando que se pierda la historia.

## Carpetas internas

- `deprecated/`: Documentos de requisitos o funcionalidades que fueron descartadas y sacadas del alcance del proyecto (ej. integración fallida con terceros).
- `old-decisions/`: Minutas de reuniones o propuestas tempranas que fueron reestructuradas en otros documentos oficiales.

*Nota:* No modifique los documentos almacenados aquí. Son de solo lectura como registro histórico.
