# Calidad

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta las estrategias para mantener la calidad del software en el sistema de gestión "La Esquina": pruebas y revisión de código.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [testing-strategy.md](./testing-strategy.md) | Enfoque de pruebas funcionales y no funcionales | 🟢 |
| [code-review.md](./code-review.md) | Proceso de revisión de código por pares | 🟢 |
