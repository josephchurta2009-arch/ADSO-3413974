# Revisión de Código

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El Code Review (revisión de código por pares) es el mecanismo principal de calidad del equipo para detectar errores tempranamente, compartir el conocimiento del sistema y asegurar que se cumplan las reglas definidas.

## Proceso de Revisión

1. **Pull Request (PR):** El desarrollador abre un PR en GitHub hacia la rama `develop`.
2. **Asignación:** Se asigna al menos a un compañero del equipo de desarrollo (ADSO SENA).
3. **Lista de chequeo para el revisor:**
   - [ ] El código cumple con el RF o la Historia de Usuario solicitada.
   - [ ] No hay credenciales (contraseñas/secretos) quemadas en el código (Reglas de Seguridad).
   - [ ] Se capturan posibles errores (ej. producto no encontrado).
   - [ ] La UI resultante usa Bootstrap y está en español (RNF-04).
   - [ ] El código es legible (variables descriptivas, métodos cortos).
4. **Aprobación:** Si todo es correcto, se aprueba y se hace merge.

## Referencias

- [00-governance/definition-of-done.md](../00-governance/definition-of-done.md)
