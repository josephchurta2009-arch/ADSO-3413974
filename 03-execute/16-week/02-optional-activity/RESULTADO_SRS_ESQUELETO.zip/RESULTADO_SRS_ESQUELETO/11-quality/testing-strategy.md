# Estrategia de Pruebas

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Para la versión 1.0 del sistema "La Esquina", desarrollada por un equipo junior, la estrategia de calidad se centrará principalmente en pruebas manuales guiadas por los casos de uso (CU) y los criterios de aceptación de las Historias de Usuario (HU).

## Pruebas Funcionales (Manuales)

El equipo realizará validación manual de los flujos críticos antes de considerar una funcionalidad como terminada (ver `00-governance/definition-of-done.md`).

**Escenarios principales a probar:**
1. **Flujo de Venta:** (CU-01 / RF-02, RF-03, RF-04)
   - Venta exitosa con productos disponibles.
   - Venta rechazada al intentar superar el stock.
   - Cálculo correcto del subtotal y total.
2. **Gestión de Inventario:** (CU-02 / RF-05, RF-06)
   - Creación exitosa de producto.
   - Activación de la alerta visual cuando el stock cae bajo el mínimo (RF-06).
3. **Autenticación:** (RF-01)
   - Bloqueo de acceso sin credenciales válidas.
   - Redirecciones correctas según el rol (Administrador vs Cajero).

## Pruebas No Funcionales

- **Usabilidad (RNF-01, RNF-04):** Validar que la interfaz es intuitiva y completamente en español (mensajes, botones, errores).
- **Rendimiento (RNF-02):** Validar en entorno local que la navegación y registro de ventas responden en menos de 2 segundos.
- **Compatibilidad (RNF-03):** Probar el uso del sistema desde el navegador Google Chrome.

## Referencias

- SRS La Esquina v1.0 — Casos de uso CU-01 a CU-03, RFs y RNFs.
