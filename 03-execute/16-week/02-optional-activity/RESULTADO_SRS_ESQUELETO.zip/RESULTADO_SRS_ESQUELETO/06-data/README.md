# Datos

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta los modelos de datos, el diccionario de entidades y la estrategia de migración del sistema de gestión del supermercado "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [models.md](./models.md) | Modelo relacional de la base de datos SQLite | 🟢 |
| [data-dictionary.md](./data-dictionary.md) | Diccionario de tablas, campos, tipos y restricciones | 🟢 |
| [migration-strategy.md](./migration-strategy.md) | Estrategia para cambios y migraciones de datos | 🟡 |
