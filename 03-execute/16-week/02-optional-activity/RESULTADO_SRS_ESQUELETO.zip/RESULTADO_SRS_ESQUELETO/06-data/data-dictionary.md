# Diccionario de Datos

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Diccionario completo de tablas y campos de la base de datos SQLite del sistema de gestión del supermercado "La Esquina".

---

## Tabla: `usuario`

| Campo | Tipo SQLite | Nulo | Valor por defecto | Descripción |
|-------|-------------|------|-------------------|-------------|
| `id` | INTEGER | NO | — | Clave primaria autoincremental |
| `nombre_usuario` | TEXT | NO | — | Nombre de acceso único del usuario |
| `password_hash` | TEXT | NO | — | Contraseña almacenada como hash (werkzeug) |
| `rol` | TEXT | NO | — | `'ADMINISTRADOR'` o `'CAJERO'` |

**Restricciones:**
- `nombre_usuario` es UNIQUE.
- `rol` solo acepta `'ADMINISTRADOR'` o `'CAJERO'` (CHECK constraint).

---

## Tabla: `producto`

| Campo | Tipo SQLite | Nulo | Valor por defecto | Descripción |
|-------|-------------|------|-------------------|-------------|
| `id` | INTEGER | NO | — | Clave primaria autoincremental |
| `codigo` | TEXT | NO | — | Código único del producto |
| `nombre` | TEXT | NO | — | Nombre descriptivo del producto |
| `precio` | REAL | NO | — | Precio unitario de venta |
| `stock_actual` | INTEGER | NO | 0 | Cantidad disponible en inventario |
| `stock_minimo` | INTEGER | NO | 5 | Umbral mínimo para alerta de stock bajo |

**Restricciones:**
- `codigo` es UNIQUE.
- `precio > 0` (CHECK).
- `stock_actual >= 0` (CHECK).
- `stock_minimo >= 0` (CHECK).

---

## Tabla: `venta`

| Campo | Tipo SQLite | Nulo | Valor por defecto | Descripción |
|-------|-------------|------|-------------------|-------------|
| `id` | INTEGER | NO | — | Clave primaria autoincremental |
| `cajero_id` | INTEGER | NO | — | FK → `usuario.id` |
| `fecha_hora` | TEXT | NO | CURRENT_TIMESTAMP | Fecha y hora del registro (ISO 8601) |
| `total` | REAL | NO | 0.0 | Total calculado automáticamente |

**Restricciones:**
- `cajero_id` referencia `usuario.id` (FOREIGN KEY).
- `total >= 0` (CHECK).
- No se permite DELETE de registros de venta.

---

## Tabla: `item_venta`

| Campo | Tipo SQLite | Nulo | Valor por defecto | Descripción |
|-------|-------------|------|-------------------|-------------|
| `id` | INTEGER | NO | — | Clave primaria autoincremental |
| `venta_id` | INTEGER | NO | — | FK → `venta.id` |
| `producto_id` | INTEGER | NO | — | FK → `producto.id` |
| `cantidad` | INTEGER | NO | — | Unidades vendidas |
| `precio_unitario` | REAL | NO | — | Precio del producto al momento de la venta |
| `subtotal` | REAL | NO | — | `cantidad × precio_unitario` |

**Restricciones:**
- `venta_id` referencia `venta.id` (FOREIGN KEY, CASCADE DELETE).
- `producto_id` referencia `producto.id` (FOREIGN KEY).
- `cantidad > 0` (CHECK).
- `precio_unitario > 0` (CHECK).

## Referencias

- SRS La Esquina v1.0 — RF-02 a RF-08.
- [models.md](./models.md) — Diagrama ER.
- [entities-and-rules.md](../02-domain/entities-and-rules.md) — Reglas de negocio.
