# Estrategia de Migración de Datos

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema parte de cero (no hay datos digitales previos — el negocio operaba con registros manuales en cuadernos). La estrategia de migración aplica principalmente a la inicialización de la base de datos y a cambios de esquema durante el desarrollo.

## Estrategia inicial — Carga de datos

### Fase 1: Inicialización del esquema

Al ejecutar el sistema por primera vez, un script `init_db.py` crea todas las tablas en la base de datos SQLite.

```python
# init_db.py
from app import db
db.create_all()
```

### Fase 2: Usuario administrador inicial

Se crea un usuario administrador por defecto para el primer acceso:

```python
# seed_admin.py
admin = Usuario(nombre_usuario='admin', rol='ADMINISTRADOR')
admin.set_password('cambiar_en_primer_uso')
db.session.add(admin)
db.session.commit()
```

### Fase 3: Carga del catálogo de productos

El propietario del negocio ingresará manualmente los productos desde la interfaz de Gestión de Productos (RF-05). No se planea migración desde hojas de papel de forma automatizada en v1.0.

## Cambios de esquema (durante desarrollo)

Al no tener herramienta de migración formal (como Alembic), el equipo sigue este proceso manual para v1.0:

1. Hacer backup del archivo `laesquina.db`.
2. Modificar el script `init_db.py` con los cambios al esquema.
3. Eliminar el archivo `.db` de desarrollo y recrearlo con `init_db.py`.
4. **Nunca** recrear la base de datos de producción sin backup previo.

## Versiones futuras

Para v2.0, se recomienda incorporar **Flask-Migrate + Alembic** para gestionar migraciones de forma controlada sin pérdida de datos.

## Referencias

- SRS La Esquina v1.0 — Tabla 1 (SQLite como BD), RF-05 (Gestión de productos).
