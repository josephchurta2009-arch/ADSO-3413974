# Modelos de Datos

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Modelo relacional de la base de datos SQLite del sistema de gestión del supermercado "La Esquina", derivado de las entidades identificadas en el SRS.

## Diagrama Entidad-Relación (conceptual)

```
┌─────────────┐       ┌──────────────────┐       ┌─────────────┐
│   USUARIO   │       │      VENTA       │       │   PRODUCTO  │
│─────────────│       │──────────────────│       │─────────────│
│ id (PK)     │──1──┐ │ id (PK)          │ ┌──N──│ id (PK)     │
│ nombre_user │     └─│ cajero_id (FK)   │ │     │ codigo      │
│ password    │       │ fecha_hora       │ │     │ nombre      │
│ rol         │       │ total            │ │     │ precio      │
└─────────────┘       └────────┬─────────┘ │     │ stock_actual│
                               │ 1         │     │ stock_minimo│
                               │           │     └─────────────┘
                      ┌────────▼─────────┐ │
                      │   ITEM_VENTA     │ │
                      │──────────────────│ │
                      │ id (PK)          │ │
                      │ venta_id (FK)  N─┘ │
                      │ producto_id (FK)───┘
                      │ cantidad         │
                      │ precio_unitario  │
                      │ subtotal         │
                      └──────────────────┘
```

## Tablas y relaciones

| Tabla | Descripción | Relaciones |
|-------|-------------|------------|
| `usuario` | Almacena usuarios con rol y credenciales | 1:N con `venta` |
| `producto` | Catálogo de productos con precio y stock | N:M con `venta` (a través de `item_venta`) |
| `venta` | Cabecera de cada venta registrada | N:1 con `usuario`, 1:N con `item_venta` |
| `item_venta` | Detalle de cada línea de una venta | N:1 con `venta`, N:1 con `producto` |

## Reglas de integridad

- `venta.total` = `SUM(item_venta.subtotal)` para esa venta.
- `item_venta.subtotal` = `item_venta.precio_unitario × item_venta.cantidad`.
- `producto.stock_actual` disminuye en `item_venta.cantidad` al confirmar la venta.
- Si `producto.stock_actual <= producto.stock_minimo` → se dispara alerta.

## Referencias

- SRS La Esquina v1.0 — RF-02 a RF-08, Tabla 3.
- [entities-and-rules.md](../02-domain/entities-and-rules.md) — Entidades de dominio.
