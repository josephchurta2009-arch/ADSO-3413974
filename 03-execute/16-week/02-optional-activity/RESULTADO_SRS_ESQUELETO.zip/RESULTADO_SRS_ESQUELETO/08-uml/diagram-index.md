# Índice de Diagramas UML

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Registro de todos los diagramas UML planificados y producidos para el sistema de gestión del supermercado "La Esquina". Los casos de uso del SRS (CU-01 a CU-03) son el punto de partida.

## Catálogo de diagramas

| ID | Tipo | Nombre | Fuente | Estado |
|----|------|--------|--------|--------|
| D-01 | Caso de Uso | Diagrama general de casos de uso del sistema | `diagrams/source/cu-general.puml` | 🔴 Pendiente |
| D-02 | Caso de Uso | CU-01: Registrar Venta (Cajero) | `diagrams/source/cu-01-registrar-venta.puml` | 🔴 Pendiente |
| D-03 | Caso de Uso | CU-02: Gestionar Productos (Admin) | `diagrams/source/cu-02-gestionar-productos.puml` | 🔴 Pendiente |
| D-04 | Caso de Uso | CU-03: Consultar Reportes (Admin) | `diagrams/source/cu-03-consultar-reportes.puml` | 🔴 Pendiente |
| D-05 | Clases | Diagrama de clases del dominio | `diagrams/source/clases-dominio.puml` | 🔴 Pendiente |
| D-06 | Secuencia | Flujo de registro de venta | `diagrams/source/seq-registrar-venta.puml` | 🔴 Pendiente |
| D-07 | Entidad-Relación | Modelo de datos SQLite | `diagrams/source/er-modelo-datos.puml` | 🔴 Pendiente |

## Actores identificados en el SRS

Del SRS Tabla 2 y los casos de uso:

```plantuml
@startuml
actor Cajero
actor Administrador

Cajero --> (CU-01: Registrar Venta)
Administrador --> (CU-02: Gestionar Productos)
Administrador --> (CU-03: Consultar Reportes)
Administrador --> (Ver alertas de stock bajo)
@enduml
```

## Convención de archivos

- Fuentes PlantUML: `diagrams/source/*.puml`
- Exportaciones SVG: `diagrams/exports/*.svg`
- Todo diagrama debe tener fuente editable (no subir solo la imagen).

## Referencias

- SRS La Esquina v1.0 — Casos de Uso CU-01, CU-02, CU-03, Tabla 2 (Actores).
