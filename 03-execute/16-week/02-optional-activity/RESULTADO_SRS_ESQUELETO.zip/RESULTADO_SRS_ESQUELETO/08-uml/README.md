# UML — Índice de diagramas

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Índice de todos los diagramas UML del sistema de gestión del supermercado "La Esquina". Los casos de uso CU-01, CU-02 y CU-03 del SRS son la base para los diagramas de casos de uso.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [diagram-index.md](./diagram-index.md) | Índice de todos los diagramas del sistema | 🟢 |
| [diagrams/](./diagrams/) | Fuentes y exportaciones de diagramas UML | 🟡 |
