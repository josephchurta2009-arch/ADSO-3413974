# Sistema de Gestión "La Esquina" - Documentación

Repositorio de documentación del proyecto formativo **Sistema de Gestión Supermercado "La Esquina"**, versión 1.0.

Este repositorio es la fuente de verdad documental del proyecto elaborado por estudiantes del programa Análisis y Desarrollo de Software Orientado (ADSO) del SENA.

## Reglas rápidas

- Leer [CONTRIBUTING.md](./CONTRIBUTING.md) antes de agregar o mover documentos.
- Registrar cada archivo nuevo en el `README.md` de su sección.
- No publicar credenciales, claves ni información sensible en el código ni en la documentación.
- Usar `99-archive/` para preservar documentos que ya no apliquen al proyecto.

## Estructura

| Sección | Descripción | Estado |
|---------|-------------|--------|
| [00-governance](./00-governance/) | Reglas, convenciones Git y de seguridad del equipo | 🟢 |
| [01-context](./01-context/) | Contexto del supermercado, alcance v1.0 y glosario | 🟢 |
| [02-domain](./02-domain/) | Entidades de negocio (Venta, Producto, Usuario) | 🟢 |
| [03-product](./03-product/) | Visión, roadmap (v1.0 vs v2.0) y backlog | 🟢 |
| [04-requirements](./04-requirements/) | Historias de Usuario, RFs, RNFs y Trazabilidad | 🟢 |
| [05-architecture](./05-architecture/) | Monolito de 3 capas (Flask + SQLite) y ADRs | 🟢 |
| [06-data](./06-data/) | Diccionario de datos y modelo Entidad-Relación | 🟢 |
| [07-api](./07-api/) | Lineamientos de rutas y flujo de autenticación | 🟢 |
| [08-uml](./08-uml/) | Índice de diagramas propuestos (basado en CUs) | 🟢 |
| [09-microservices](./09-microservices/) | Módulo Deprecado (El sistema es Monolítico) | ⚫ |
| [10-devops](./10-devops/) | Setup local para el equipo y despliegue simple | 🟢 |
| [11-quality](./11-quality/) | Pruebas manuales funcionales y de QA | 🟢 |
| [12-ux-ui](./12-ux-ui/) | Wireframes y uso de Bootstrap | 🟢 |
| [13-operations](./13-operations/) | Gestión de backups de base de datos local | 🟢 |
| [14-training](./14-training/) | Manuales de Administrador y Cajero | 🟢 |
| [15-project-control](./15-project-control/) | Deuda técnica y matriz de riesgos operativos | 🟢 |
| [99-archive](./99-archive/) | Documentos históricos | 🟢 |

## Estado de íconos
- 🔴 Pendiente — 🟡 En progreso — 🟢 Estable
- ⚫ Deprecado

## Documentos de gobierno

- [Guía de contribución](./CONTRIBUTING.md)
- [Reglas de documentación](./00-governance/documentation-rules.md)
- [Convenciones de Git](./00-governance/git-conventions.md)
- [Seguridad documental](./00-governance/security-rules.md)
- [Definition of Ready](./00-governance/definition-of-ready.md)
- [Definition of Done](./00-governance/definition-of-done.md)
- [CHANGELOG](./CHANGELOG.md)
