# Manual del Administrador

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Instructivo de uso para el **ADMINISTRADOR** (propietario o encargado del negocio), que tiene acceso total.

## Funciones Principales

### 1. Gestionar Productos (RF-05)
- Vaya a la pestaña **Productos**.
- Para agregar uno nuevo, haga clic en "+ Nuevo Producto". Llene código, nombre, precio, stock actual y stock mínimo.
- Para cambiar un precio, busque el producto y haga clic en el botón de edición (Lápiz).

### 2. Atender Alertas de Stock (RF-06)
- Al iniciar sesión, la pantalla principal le mostrará una advertencia amarilla o roja por cada producto que tenga poco stock.
- Revise estos mensajes diariamente para saber qué productos pedir a los proveedores.

### 3. Consultar Reportes de Ventas (RF-07)
- Vaya a la pestaña **Reportes**.
- Seleccione la fecha que desea revisar.
- El sistema le mostrará un resumen del total de dinero ingresado y la lista de todo lo que se vendió ese día.

### 4. Realizar Copia de Seguridad (Muy Importante)
- Al cerrar el negocio, recuerde copiar el archivo de la base de datos (`laesquina.db`) a su memoria USB, como se indica en la política de Backups.
