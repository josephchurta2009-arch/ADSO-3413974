# Inducción Técnica

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Bienvenidos al Proyecto "La Esquina"

Este documento es la entrada para estudiantes ADSO que se unan al equipo de desarrollo.

## Lo que debes saber

1. **El Cliente:** Es un supermercado de barrio, procesos manuales, computadores básicos (ver [01-context/overview.md](../01-context/overview.md)).
2. **El Sistema (v1.0):** Es un Monolito Web. Nada de microservicios, APIs complejas o despliegues en la nube.
3. **El Stack:** HTML, CSS, JavaScript (Vanilla), Flask (Python) y SQLite. Usamos Bootstrap para no perder tiempo en estilos (ver [ADR-001](../05-architecture/decisions/records/ADR-001-stack-tecnologico.md)).

## Tu primer día

1. Lee los **Requerimientos Funcionales** ([04-requirements/functional.md](../04-requirements/functional.md)) para entender qué hace el sistema.
2. Sigue la guía de **Configuración Local** ([10-devops/local-setup.md](../10-devops/local-setup.md)) para tener el sistema corriendo en tu máquina.
3. Revisa los **Modelos de Datos** ([06-data/models.md](../06-data/models.md)) para entender cómo se guardan las ventas y productos.
4. Toma una tarea del **Backlog** ([03-product/product-backlog.md](../03-product/product-backlog.md)).
