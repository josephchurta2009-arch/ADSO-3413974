# Manual de Usuario - Cajero

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Instructivo de uso para el rol **CAJERO**, cuyo objetivo principal es registrar ventas de forma rápida (RF-02).

## Paso a paso: Cómo registrar una venta

1. **Ingresar al sistema:**
   - Abra el navegador web (ej. Google Chrome).
   - Escriba sus credenciales (usuario y contraseña) entregadas por el administrador.
   - Haga clic en "Iniciar Sesión".

2. **Agregar productos:**
   - En la pantalla principal ("Nueva Venta"), use el buscador escribiendo el nombre del producto o el código.
   - Indique la cantidad que lleva el cliente.
   - El sistema calculará el total automáticamente (RF-03).

3. **Confirmar:**
   - Una vez agregados todos los productos, verifique el total en pantalla.
   - Reciba el pago del cliente y haga clic en **"Confirmar Venta"**.
   - El inventario se actualizará solo. El sistema quedará limpio y listo para el siguiente cliente.

## Solución de problemas comunes
- **"Stock Insuficiente":** Significa que en el sistema hay menos unidades de las que el cliente quiere llevar. Avise al administrador.
