# Capacitación

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Manuales e instructivos para los diferentes perfiles del sistema de gestión "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [user-manual.md](./user-manual.md) | Manual para el Cajero (Registrar ventas) | 🟢 |
| [admin-manual.md](./admin-manual.md) | Manual para el Administrador (Gestión y reportes) | 🟢 |
| [technical-onboarding.md](./technical-onboarding.md) | Inducción para nuevos desarrolladores | 🟢 |
