# Despliegue

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El SRS establece que el sistema debe funcionar en los computadores básicos del negocio (RNF-03). No se define despliegue en la nube para la versión 1.0; el sistema opera de forma local.

## Topología de despliegue — v1.0

```
┌─────────────────────────────────────────────────┐
│             Computador del negocio              │
│                                                 │
│  ┌───────────────────────────────────────────┐  │
│  │          Servidor Flask (local)           │  │
│  │   python app.py  →  http://localhost:5000 │  │
│  │                                           │  │
│  │   /ventas  /productos  /reportes          │  │
│  │   /login   /inventario                    │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
│  ┌───────────────────────────────────────────┐  │
│  │          Base de datos SQLite             │  │
│  │   laesquina.db  (archivo local)           │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
│  ┌───────────────────────────────────────────┐  │
│  │     Navegador web (Chrome / Firefox)      │  │
│  │   Accede a http://localhost:5000          │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

## Ambientes

| Ambiente | Descripción | Base de datos |
|----------|-------------|---------------|
| Desarrollo | Equipo local del desarrollador | `dev.db` (datos de prueba) |
| Producción | Computador del negocio La Esquina | `laesquina.db` (datos reales) |

## Requisitos del entorno de producción

| Requisito | Especificación mínima |
|-----------|-----------------------|
| Sistema Operativo | Windows 10 o superior |
| Navegador | Chrome o Firefox (versión actual) |
| Python | 3.10 o superior |
| RAM | 4 GB mínimo |
| Almacenamiento | 500 MB disponibles |
| Red | No requerida (opera de forma local) |

## Referencias

- SRS La Esquina v1.0 — RNF-03 (Compatibilidad con computadores básicos), Tabla 1 (Stack tecnológico).
