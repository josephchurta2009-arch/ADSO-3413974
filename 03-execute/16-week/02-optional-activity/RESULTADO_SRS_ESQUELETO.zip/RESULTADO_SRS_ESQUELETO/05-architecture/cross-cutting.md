# Aspectos transversales

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Aspectos que aplican de forma transversal a todos los módulos del sistema de gestión del supermercado "La Esquina".

## Autenticación y sesiones

- Flask gestiona las sesiones mediante la extensión `flask-login` o el objeto `session` nativo.
- Las contraseñas se almacenan con hash (ej: `werkzeug.security.generate_password_hash`).
- Toda ruta protegida valida que exista una sesión activa antes de procesar la solicitud.
- Si no hay sesión válida, el sistema redirige al formulario de login.

**Origen:** RF-01, RNF-05.

## Autorización por rol

- El rol del usuario (ADMINISTRADOR o CAJERO) se almacena en la sesión al momento del login.
- Un decorador personalizado (ej: `@require_admin`) protege las rutas restringidas al Administrador.
- El Cajero solo puede acceder al módulo de ventas.

**Origen:** Tabla 2 del SRS (Perfiles de Usuario), RNF-05.

## Manejo de errores

- Los errores de validación (campos vacíos, stock insuficiente, credenciales incorrectas) muestran mensajes descriptivos en español.
- Los errores 404 y 500 tienen páginas de error personalizadas en español (RNF-04).
- Nunca se exponen detalles técnicos del servidor al usuario final.

## Internacionalización

- Todo el sistema está en español: textos de UI, mensajes de error, alertas y reportes (RNF-04).
- No se requiere soporte multiidioma en v1.0.

## Rendimiento

- El tiempo de respuesta objetivo es ≤ 2 segundos para todas las operaciones (RNF-02).
- SQLite es adecuado para el volumen esperado (pequeño negocio de barrio, < 200 ventas/día).

## Logging básico

- Flask registra errores del servidor en consola durante el desarrollo.
- Para producción, se recomienda redirigir los logs a un archivo local (`app.log`).

## Referencias

- SRS La Esquina v1.0 — RF-01, RNF-02, RNF-04, RNF-05, Tabla 2.
