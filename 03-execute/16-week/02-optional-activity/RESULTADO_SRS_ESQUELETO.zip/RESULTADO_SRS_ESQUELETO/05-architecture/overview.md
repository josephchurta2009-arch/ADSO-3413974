# Arquitectura — Vista General

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Arquitectura definida en el SRS v1.0 para el sistema de gestión del supermercado "La Esquina". El sistema sigue una arquitectura **web monolítica de tres capas**, adecuada para un equipo junior y un negocio pequeño.

## Estilo arquitectónico

**Web Monolítica — 3 Capas:**

```
┌────────────────────────────────────┐
│         CAPA DE PRESENTACIÓN       │
│   HTML + CSS + JavaScript          │
│   Bootstrap (diseño UI)            │
│   Navegador web del usuario        │
└─────────────────┬──────────────────┘
                  │ HTTP Request/Response
┌─────────────────▼──────────────────┐
│         CAPA DE APLICACIÓN         │
│   Python con Flask (Backend)       │
│   Rutas, controladores y lógica    │
│   Autenticación y autorización     │
└─────────────────┬──────────────────┘
                  │ SQL Queries
┌─────────────────▼──────────────────┐
│         CAPA DE DATOS              │
│   SQLite (Base de datos)           │
│   Archivo local en el servidor     │
└────────────────────────────────────┘
```

## Componentes principales

| Componente | Tecnología | Responsabilidad |
|------------|-----------|-----------------|
| Frontend | HTML, CSS, JavaScript, Bootstrap | Interfaz de usuario (formularios, tablas, alertas) |
| Backend | Python 3 + Flask | Lógica de negocio, rutas HTTP, sesiones |
| Base de datos | SQLite | Persistencia de productos, ventas, usuarios |
| Control de versiones | Git + GitHub | Versionado del código fuente |

## Módulos del sistema

| Módulo | Descripción | RF que implementa |
|--------|-------------|-------------------|
| Autenticación | Login/logout, manejo de sesiones y roles | RF-01 |
| Ventas | Registro de ventas, cálculo de total | RF-02, RF-03, RF-08 |
| Inventario | Actualización de stock, alertas de stock bajo | RF-04, RF-06 |
| Productos | CRUD del catálogo de productos | RF-05 |
| Reportes | Generación y visualización de reportes de ventas | RF-07 |

## Razón del stack elegido

> Tomado literalmente del SRS: *"El sistema será desarrollado con tecnologías adecuadas para un equipo de desarrollo junior, priorizando la simplicidad y la accesibilidad."*

- **Flask:** framework Python ligero, ideal para proyectos pequeños y equipos juniors.
- **SQLite:** base de datos sin servidor, sin instalación adicional, suficiente para el volumen de un negocio de barrio.
- **Bootstrap:** garantiza una UI consistente y responsive con mínimo CSS personalizado.

## Referencias

- SRS La Esquina v1.0 — Tabla 1 (Pila Tecnológica), Sección "Tecnologías del Proyecto".
