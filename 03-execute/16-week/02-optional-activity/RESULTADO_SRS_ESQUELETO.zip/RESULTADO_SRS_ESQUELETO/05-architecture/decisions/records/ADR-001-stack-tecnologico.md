# ADR-001 — Selección del Stack Tecnológico

> Estado: Aceptada | Fecha: 2025
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El equipo de desarrollo está conformado por estudiantes junior del programa ADSO del SENA. Se requiere un stack tecnológico que sea accesible para el nivel del equipo, opere en computadores básicos del negocio y sea suficiente para el volumen de operaciones de un supermercado de barrio.

## Problema

¿Qué tecnologías usar para desarrollar el sistema de gestión del supermercado "La Esquina"?

## Opciones consideradas

| Opción | Ventajas | Desventajas |
|--------|----------|-------------|
| Flask + SQLite | Ligero, Python conocido por el equipo, sin servidor de BD separado | No escala a múltiples sucursales |
| Django + PostgreSQL | Más robusto, admin incluido | Curva de aprendizaje mayor para juniors |
| Node.js + MongoDB | Popular, JS en todo | El equipo no tiene experiencia previa suficiente |
| PHP + MySQL | Muy documentado | Stack no alineado con el programa ADSO |

## Decisión

**Usar HTML/CSS/JavaScript + Python/Flask + SQLite + Bootstrap**, tal como se define en la Tabla 1 del SRS.

## Justificación

> *"El sistema será desarrollado con tecnologías adecuadas para un equipo de desarrollo junior, priorizando la simplicidad y la accesibilidad."* — SRS La Esquina v1.0

- Python/Flask es el lenguaje principal enseñado en ADSO.
- SQLite no requiere instalación ni configuración de servidor de base de datos.
- Bootstrap garantiza una UI funcional y consistente con mínimo esfuerzo.

## Consecuencias

- ✅ Equipo puede desarrollar sin bloqueos por tecnología desconocida.
- ✅ Despliegue simple en el computador del negocio sin infraestructura adicional.
- ⚠️ SQLite no soporta concurrencia alta ni múltiples sucursales (fuera del alcance v1.0).
- ⚠️ Flask no provee admin automático (hay que construir todo desde cero).

## Referencias

- SRS La Esquina v1.0 — Tabla 1 (Pila Tecnológica), Sección "Tecnologías del Proyecto".
