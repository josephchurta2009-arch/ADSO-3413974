# Decisiones de Arquitectura (ADR)

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Registro de decisiones de arquitectura tomadas para el sistema de gestión del supermercado "La Esquina".

## Índice de ADRs

| ID | Título | Estado | Fecha |
|----|--------|--------|-------|
| [ADR-001](./records/ADR-001-stack-tecnologico.md) | Selección del stack tecnológico (Flask + SQLite) | Aceptada | 2025 |
| [ADR-002](./records/ADR-002-arquitectura-monolitica.md) | Arquitectura monolítica de 3 capas | Aceptada | 2025 |

## Formato de registro

Cada ADR en `records/` sigue el formato `ADR-NNN-titulo-corto.md` y contiene:
- Contexto y problema
- Opciones consideradas
- Decisión tomada
- Consecuencias
