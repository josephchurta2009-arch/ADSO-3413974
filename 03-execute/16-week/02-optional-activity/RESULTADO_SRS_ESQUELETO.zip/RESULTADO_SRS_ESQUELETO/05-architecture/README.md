# Arquitectura

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Describe la arquitectura del sistema de gestión del supermercado "La Esquina", el despliegue, las decisiones técnicas y los aspectos transversales.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Vista general de la arquitectura y componentes del sistema | 🟢 |
| [deployment.md](./deployment.md) | Topología de despliegue y ambientes | 🟡 |
| [cross-cutting.md](./cross-cutting.md) | Seguridad, manejo de errores y aspectos transversales | 🟢 |
| [decisions/](./decisions/) | Registro de decisiones de arquitectura (ADR) | 🟡 |
