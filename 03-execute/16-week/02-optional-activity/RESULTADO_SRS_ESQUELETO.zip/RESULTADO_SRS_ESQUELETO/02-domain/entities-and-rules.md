# Entidades y reglas de dominio

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Entidades de negocio identificadas en el SRS del supermercado "La Esquina" y las reglas que las rigen.

## Entidades

### Usuario

Representa a las personas que pueden acceder al sistema.

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| nombre_usuario | String | Identificador único de acceso |
| contraseña | String (hash) | Credencial de autenticación |
| rol | Enum | `ADMINISTRADOR` o `CAJERO` |

**Reglas de dominio:**
- Un usuario solo puede autenticarse con usuario y contraseña válidos (RF-01).
- El rol determina qué módulos del sistema puede usar (RNF-05).
- No pueden existir dos usuarios con el mismo nombre de usuario.

---

### Producto

Artículo disponible en el inventario del supermercado.

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| codigo | String | Identificador único del producto |
| nombre | String | Nombre descriptivo del producto |
| precio | Decimal | Precio unitario de venta |
| stock_actual | Integer | Cantidad disponible en inventario |
| stock_minimo | Integer | Umbral mínimo antes de emitir alerta |

**Reglas de dominio:**
- Solo el Administrador puede agregar, editar o eliminar productos (RF-05).
- Si `stock_actual <= stock_minimo`, el sistema emite una alerta de stock bajo (RF-06).
- El `precio` no puede ser negativo ni cero.
- El `stock_actual` no puede ser negativo.

---

### Venta

Transacción registrada por un Cajero en el sistema.

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id_venta | Integer | Identificador único de la venta |
| fecha_hora | DateTime | Fecha y hora del registro |
| cajero | Usuario | Usuario que realizó la venta |
| items | Lista\<ItemVenta\> | Productos incluidos en la venta |
| total | Decimal | Suma calculada automáticamente |

**Reglas de dominio:**
- El total se calcula automáticamente como suma de `(precio × cantidad)` por cada ítem (RF-03).
- Al confirmar la venta, el stock de cada producto vendido se actualiza automáticamente (RF-04).
- Las ventas se guardan permanentemente en el historial (RF-08).
- No se pueden eliminar ventas del historial.

---

### ItemVenta

Línea de detalle de una venta.

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| producto | Producto | Referencia al producto vendido |
| cantidad | Integer | Unidades vendidas |
| precio_unitario | Decimal | Precio en el momento de la venta |
| subtotal | Decimal | `precio_unitario × cantidad` |

**Reglas de dominio:**
- La `cantidad` debe ser mayor que cero.
- El `precio_unitario` se captura en el momento de la venta (no varía si el precio cambia después).
- No se puede vender un producto si `stock_actual < cantidad` solicitada.

## Referencias

- SRS La Esquina v1.0 — RF-01, RF-02, RF-03, RF-04, RF-05, RF-06, RF-08, Tabla 2, CU-01, CU-02.
