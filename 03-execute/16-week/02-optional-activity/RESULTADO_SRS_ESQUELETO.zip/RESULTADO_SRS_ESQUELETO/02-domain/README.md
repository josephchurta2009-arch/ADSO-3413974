# Dominio

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contenido

Define el modelo de dominio del sistema de gestión del supermercado "La Esquina": entidades de negocio, sus reglas, eventos y el mapa del dominio.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [domain-map.md](./domain-map.md) | Mapa de los subdominios y sus relaciones | 🟢 |
| [entities-and-rules.md](./entities-and-rules.md) | Entidades de negocio y sus reglas de dominio | 🟢 |
| [domain-events.md](./domain-events.md) | Eventos relevantes que ocurren en el dominio | 🟢 |
