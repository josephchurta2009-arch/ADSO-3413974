# Eventos de dominio

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Eventos de negocio relevantes que ocurren en el dominio del supermercado "La Esquina" y que el sistema debe detectar, registrar o reaccionar ante ellos.

## Catálogo de eventos

| Evento | Desencadenante | Reacción del sistema | RF/RNF relacionado |
|--------|---------------|---------------------|---------------------|
| `VentaRegistrada` | Cajero confirma una venta | Calcular total, actualizar stock, guardar en historial | RF-02, RF-03, RF-04, RF-08 |
| `StockActualizado` | Se confirma una venta | Restar unidades vendidas del stock del producto | RF-04 |
| `AlertaStockBajo` | Stock de un producto cae ≤ stock mínimo | Mostrar alerta visible al Administrador | RF-06 |
| `ProductoCreado` | Administrador agrega un producto | Producto queda disponible en catálogo e inventario | RF-05 |
| `ProductoEditado` | Administrador modifica datos de un producto | Datos actualizados en catálogo e inventario | RF-05 |
| `ProductoEliminado` | Administrador elimina un producto | Producto removido del catálogo (no de historial de ventas) | RF-05 |
| `SesionIniciada` | Usuario ingresa credenciales válidas | Sistema concede acceso según rol | RF-01, RNF-05 |
| `ReporteConsultado` | Administrador solicita reporte de ventas | Sistema muestra ventas filtradas por fecha | RF-07 |

## Referencias

- SRS La Esquina v1.0 — RF-01 a RF-08, Casos de Uso CU-01, CU-02, CU-03.
