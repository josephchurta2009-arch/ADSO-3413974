# Mapa de dominio

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema de gestión del supermercado "La Esquina" se estructura en torno a tres subdominios principales que reflejan las responsabilidades operativas del negocio.

## Subdominios

```
┌──────────────────────────────────────────────────────────────┐
│         Sistema de Gestión — Supermercado "La Esquina"       │
├────────────────┬──────────────────┬──────────────────────────┤
│  Subdomain:    │  Subdomain:      │  Subdomain:              │
│  VENTAS        │  INVENTARIO      │  ADMINISTRACIÓN          │
│                │                  │                          │
│  - Registrar   │  - Productos     │  - Usuarios / Roles      │
│    venta       │  - Stock         │  - Reportes              │
│  - Calcular    │  - Alertas       │  - Configuración         │
│    total       │    stock bajo    │                          │
│  - Historial   │  - Actualizar    │                          │
│    de ventas   │    stock         │                          │
└────────────────┴──────────────────┴──────────────────────────┘
```

## Relaciones entre subdominios

| Relación | Descripción |
|----------|-------------|
| Ventas → Inventario | Cada venta registrada dispara una actualización de stock en el inventario |
| Inventario → Ventas | El inventario valida que haya stock suficiente antes de confirmar una venta |
| Administración → Inventario | El administrador puede gestionar productos y ver el estado del stock |
| Administración → Ventas | El administrador puede consultar el historial y reportes de ventas |

## Actores del dominio

| Actor | Subdominios que usa |
|-------|---------------------|
| Administrador | Inventario, Ventas (reportes), Administración |
| Cajero | Ventas |

## Referencias

- SRS La Esquina v1.0 — Tabla 2 (Perfiles de Usuario), Sección Requerimientos Funcionales, Casos de Uso CU-01 a CU-03.
