# UX/UI

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documenta el sistema de diseño, mapa de navegación y referencias visuales de la interfaz de usuario del sistema de gestión "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [design-system.md](./design-system.md) | Patrones visuales, colores y tipografía basados en Bootstrap | 🟢 |
| [navigation-map.md](./navigation-map.md) | Mapa de jerarquía de pantallas por roles | 🟢 |
| [wireframes.md](./wireframes.md) | Referencias de distribución de las pantallas clave | 🟡 |
