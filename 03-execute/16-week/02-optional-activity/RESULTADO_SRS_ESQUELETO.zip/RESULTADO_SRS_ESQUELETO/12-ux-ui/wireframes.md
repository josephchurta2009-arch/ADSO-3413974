# Wireframes

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Esquemas de baja fidelidad propuestos para las pantallas clave del sistema web, diseñadas utilizando la grilla y componentes de Bootstrap.

## 1. Pantalla Login (Todos)

```
=========================================
|        SISTEMA "LA ESQUINA"           |
=========================================
|                                       |
|    [  Ingresar Usuario       ]        |
|    [  Ingresar Contraseña    ]        |
|                                       |
|    [       Iniciar Sesión    ]        |
|                                       |
=========================================
```

## 2. Pantalla Registro de Venta (Cajero/Admin)

```
[ Sistema La Esquina ] [ Cerrar Sesión ]
=========================================
| NUEVA VENTA                 (RF-02)   |
|---------------------------------------|
| Buscar Producto: [ Código/Nombre ] [+]|
|---------------------------------------|
| Producto  | Cant | P.Unit | Subtotal  |
| Arroz     | 2    | $2500  | $5000     |
| Leche     | 1    | $3000  | $3000     |
|---------------------------------------|
| TOTAL A PAGAR: $8000                  |
|                                       |
| [ Cancelar Venta ]  [ CONFIRMAR VENTA]|
=========================================
```

## 3. Pantalla Dashboard / Alertas (Admin)

```
[ Sistema La Esquina ] [ Productos ] [ Reportes ] [ Ventas ] [ Salir ]
=========================================
| PANEL DE ADMINISTRADOR                |
|---------------------------------------|
| ⚠️ ALERTAS DE STOCK (RF-06)            |
| - Producto: Aceite (Quedan: 2 un.)    |
| - Producto: Huevos (Quedan: 5 un.)    |
|---------------------------------------|
|                                       |
| [ Ir a Catálogo ]   [ Ver Ventas Hoy ]|
=========================================
```

## 4. Pantalla Catálogo (Admin)

```
[ Menú Admin ]
=========================================
| GESTIÓN DE PRODUCTOS (RF-05)          |
|---------------------------------------|
| [ + Nuevo Producto ]                  |
|---------------------------------------|
| Cód  | Nombre   | Precio | Stock | Ac |
| 001  | Arroz    | $2500  | 50    |✎ 🗑|
| 002  | Leche    | $3000  | 10    |✎ 🗑|
=========================================
```

## Referencias

- SRS La Esquina v1.0 — Requerimientos Funcionales RF-01, RF-02, RF-05, RF-06.
