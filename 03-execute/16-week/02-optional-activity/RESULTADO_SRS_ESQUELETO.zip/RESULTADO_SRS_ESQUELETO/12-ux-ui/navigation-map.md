# Mapa de Navegación

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Representa la estructura de pantallas y cómo el usuario navega a través de ellas. La navegación está fuertemente condicionada por el rol del usuario (RNF-05).

## Mapa de Pantallas

### Área Pública
- **[Pantalla Login]** (`/login`)
  - Redirige a **Panel Cajero** si el rol es CAJERO.
  - Redirige a **Panel Admin** si el rol es ADMINISTRADOR.

### Área Privada: Cajero
- **[Panel Cajero: Nueva Venta]** (`/ventas/nueva`)
  - Pantalla principal y única para este rol.
  - Buscador de productos.
  - Tabla dinámica de la venta actual (items, subtotal, total).
  - Botón: Confirmar Venta.
  - Botón: Cerrar Sesión.

### Área Privada: Administrador
- **[Panel Admin: Dashboard / Alertas]** (`/`)
  - Muestra alertas visuales inmediatas si hay stock bajo (RF-06).
  - Menú de navegación principal.

- **[Módulo Ventas]** (`/ventas`)
  - **Nueva Venta** (Igual al cajero).
  - **Historial de Ventas** (Lista de ventas pasadas).

- **[Módulo Inventario y Productos]** (`/productos`)
  - Lista de productos con stock actual.
  - Botón: **Agregar Producto** → Formulario.
  - Botón: **Editar Producto** → Formulario.
  - Botón: **Eliminar Producto** → Acción de confirmación.

- **[Módulo Reportes]** (`/reportes`)
  - Formulario de filtro de fechas.
  - Tabla de resultados consolidados de ventas.

## Referencias

- SRS La Esquina v1.0 — RF-01 a RF-08, Tabla 2 (Perfiles).
