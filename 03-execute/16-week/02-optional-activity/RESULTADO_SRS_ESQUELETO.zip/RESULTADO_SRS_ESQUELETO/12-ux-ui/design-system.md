# Sistema de Diseño

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El sistema de gestión "La Esquina" utiliza **Bootstrap** (versión reciente recomendada) como base para la interfaz de usuario, según lo especificado en la Tabla 1 del SRS. El enfoque es usabilidad, limpieza y cumplimiento del requerimiento RNF-01 (Fácil de usar).

## Reglas Generales

- **Idioma:** Todo el sistema, botones, alertas y textos deben estar en **español** (RNF-04).
- **Responsive:** Aunque se usará en computadores básicos (RNF-03), el diseño usará las grillas de Bootstrap para adaptarse a diferentes tamaños de monitor.

## Paleta de Colores (Clases Bootstrap)

- **Acción Principal:** `btn-primary` (Azul) para botones de confirmar venta, guardar producto, iniciar sesión.
- **Acción Secundaria / Cancelar:** `btn-secondary` (Gris) para volver atrás o cancelar.
- **Acción Destructiva:** `btn-danger` (Rojo) para eliminar un producto del catálogo.
- **Alertas / Stock Bajo:** `text-danger` (Texto Rojo) o `alert-warning` (Caja Amarilla) para alertas visuales (RF-06).

## Componentes Frecuentes

- **Formularios:** Uso de `form-control` y etiquetas claras (`label`).
- **Tablas:** Uso de `table`, `table-striped` y `table-hover` para catálogos de productos y reportes de ventas.
- **Navegación:** `navbar` en la parte superior con los enlaces según el rol y botón de "Cerrar sesión".
- **Mensajes de Retroalimentación:** `alert` de Bootstrap (Flash messages en Flask) para indicar operaciones exitosas o errores.

## Referencias

- SRS La Esquina v1.0 — RNF-01 (Fácil de usar), RNF-04 (Interfaz en español), Tabla 1 (Diseño UI Bootstrap).
