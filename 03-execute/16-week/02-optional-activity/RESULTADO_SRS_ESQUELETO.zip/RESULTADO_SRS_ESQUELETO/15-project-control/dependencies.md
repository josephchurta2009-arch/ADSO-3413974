# Dependencias

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Dependencias Técnicas

- **Entorno del Cliente:** El sistema depende de que el supermercado proporcione un equipo de cómputo funcional con sistema operativo operativo y un navegador web instalado.
- **Librerías Externas:** El sistema depende del framework Flask y las librerías descritas en el archivo `requirements.txt`.
- **Conectividad:** Dado que es una aplicación local, NO hay dependencia de Internet (proveedores ISP) para su funcionamiento principal (v1.0).

## Dependencias Funcionales

- Las alertas de stock (RF-06) dependen funcionalmente de que el Cajero registre correctamente cada venta (RF-02) para que el inventario se actualice (RF-04).
- Los reportes (RF-07) dependen de que las ventas no sean borradas del historial (RF-08).
