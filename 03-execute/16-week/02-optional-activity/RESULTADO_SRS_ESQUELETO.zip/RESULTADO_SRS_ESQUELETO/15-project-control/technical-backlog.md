# Technical Backlog

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Registro de deuda técnica, mejoras de infraestructura y refactorizaciones de código que no afectan directamente a nuevas funcionalidades, pero mejoran el mantenimiento del sistema.

## Deuda Técnica v1.0

1. **Gestión de Migraciones de BD:**
   - Actualmente SQLite se maneja borrando y creando el archivo en desarrollo (`init_db.py`).
   - *Tarea:* Implementar `Flask-Migrate` (Alembic) para aplicar cambios a la base de datos sin perder información.

2. **Seguridad y `.env`:**
   - Asegurarse de que `SECRET_KEY` no quede "quemada" en el código fuente de Flask antes de desplegar en producción.

3. **Pruebas Automatizadas:**
   - La estrategia actual (`11-quality/testing-strategy.md`) se basa en pruebas manuales.
   - *Tarea:* Incorporar `pytest` para automatizar al menos la prueba de la función matemática que calcula el Total de la Venta (RF-03).
