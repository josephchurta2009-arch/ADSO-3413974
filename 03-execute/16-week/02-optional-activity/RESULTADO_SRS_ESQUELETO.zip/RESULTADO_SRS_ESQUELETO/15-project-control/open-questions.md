# Preguntas Abiertas

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Preguntas Abiertas

| # | Pregunta | Área | Responsable | Fecha límite | Estado | Resolución / ADR |
|---|----------|------|-------------|--------------|--------|------------------|
| 1 | ¿Qué sucede si una venta se registró por error? ¿Debe el administrador poder anularla y devolver el stock? | Requisitos / Ventas | Equipo Análisis | Próx. sprint | ABIERTA | |
| 2 | ¿Se manejarán productos a granel (ej. 0.5 kg de queso) o solo unidades enteras? | Datos / Producto | Equipo Datos | Próx. sprint | ABIERTA | |
| 3 | ¿Cómo se hará el llenado inicial de la base de datos si el negocio tiene 500 productos diferentes en papel? | Operaciones | Todos | Próx. sprint | ABIERTA | |

## Resueltas

| # | Pregunta | Área | Resolución | ADR / Doc relacionado |
|---|----------|------|------------|-----------------------|
| - | - | - | - | - |
