# Matriz de Riesgos

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Riesgos del Proyecto v1.0

| ID | Riesgo | Impacto | Probabilidad | Mitigación |
|----|--------|---------|--------------|------------|
| R-01 | Pérdida del archivo `laesquina.db` por daño de hardware. | Alto | Medio | Capacitar al administrador sobre copias de seguridad diarias (ver Manual de Admin). |
| R-02 | El equipo junior se atrasa en la entrega de funcionalidades. | Medio | Alto | Priorizar el registro de ventas (RF-02) e Inventario (RF-04) sobre los Reportes (RF-07). |
| R-03 | El computador del negocio es demasiado lento para la web. | Alto | Bajo | Usar Bootstrap ligero, evitar animaciones pesadas y cumplir el RNF-03 probando en hardware viejo. |
| R-04 | Cajero rechaza el sistema porque es más lento que el cuaderno. | Alto | Medio | Hacer el flujo de UI de ventas muy rápido (usar teclado para buscar, Enter para confirmar). |
