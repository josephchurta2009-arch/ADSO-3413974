# Control de Proyecto

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contenido

Documentación de gestión de proyecto: riesgos, dependencias, preguntas abiertas y deuda técnica.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [risks.md](./risks.md) | Matriz de riesgos operativos y técnicos | 🟢 |
| [dependencies.md](./dependencies.md) | Dependencias externas y bloqueos | 🟢 |
| [open-questions.md](./open-questions.md) | Preguntas sin resolver y su seguimiento | 🟡 |
| [technical-backlog.md](./technical-backlog.md) | Registro de deuda técnica y refactorizaciones | 🟢 |
