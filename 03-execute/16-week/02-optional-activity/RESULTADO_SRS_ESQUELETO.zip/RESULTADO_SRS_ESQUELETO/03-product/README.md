# Producto

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contenido

Define la visión del producto, el roadmap de versiones y el backlog de alto nivel del sistema de gestión del supermercado "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [vision.md](./vision.md) | Visión del producto, propuesta de valor y usuarios objetivo | 🟢 |
| [roadmap.md](./roadmap.md) | Mapa de versiones y funcionalidades planeadas | 🟢 |
| [product-backlog.md](./product-backlog.md) | Lista priorizada de funcionalidades a desarrollar | 🟢 |
