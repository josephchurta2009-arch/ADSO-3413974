# Visión del producto

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contexto

Visión del sistema de gestión para el supermercado "La Esquina", definida a partir del SRS versión 1.0.

## Propuesta de valor

> **Para el supermercado "La Esquina"**, un negocio pequeño de barrio en Neiva, Huila,  
> **que actualmente opera con registros manuales** de ventas e inventario,  
> el **Sistema de Gestión La Esquina** es una **aplicación web sencilla**  
> **que digitaliza el control de ventas e inventario** en tiempo real,  
> reduciendo errores de cálculo, eliminando el registro en papel  
> y facilitando la toma de decisiones del propietario.  
> **A diferencia de sistemas complejos de gestión empresarial**,  
> este sistema está diseñado para computadores básicos, es fácil de usar  
> y está completamente en español.

## Usuarios objetivo

| Usuario | Necesidad principal |
|---------|---------------------|
| Propietario / Administrador | Controlar el inventario, ver reportes de ventas, gestionar productos |
| Cajero | Registrar ventas de forma rápida y sin errores de cálculo |

## Problema que resuelve

| Problema actual | Solución que provee el sistema |
|-----------------|-------------------------------|
| Registro manual de ventas en cuadernos | Registro digital con cálculo automático del total |
| Errores en cierres de caja | Cálculo automático elimina errores manuales |
| Sin control de inventario | Inventario actualizado en tiempo real tras cada venta |
| Productos agotados sin aviso | Alertas automáticas de stock bajo |
| Demora al consultar precios | Búsqueda de productos por nombre o código |

## Criterio de éxito (v1.0)

- El cajero puede registrar una venta completa en menos de 2 minutos.
- El administrador puede ver el stock actual de cualquier producto en menos de 30 segundos.
- Los reportes de ventas del día se generan en menos de 2 segundos.
- Cero errores de cálculo en el total de ventas (automatizado).

## Referencias

- SRS La Esquina v1.0 — Resumen, Introducción, Problema Actual, Objetivo del Sistema.
