# Roadmap

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Mapa de versiones del sistema de gestión del supermercado "La Esquina". El SRS define una versión 1.0 con funcionalidades básicas, dejando fuera del alcance un conjunto de funcionalidades para versiones futuras.

## Versión 1.0 — MVP (En desarrollo)

**Meta:** Digitalizar las operaciones básicas del supermercado.

| Funcionalidad | Estado |
|---------------|--------|
| Autenticación con usuario y contraseña | 🔴 Pendiente |
| Roles: Administrador y Cajero | 🔴 Pendiente |
| Registro de ventas con cálculo automático | 🔴 Pendiente |
| Actualización automática de inventario | 🔴 Pendiente |
| Gestión de productos (CRUD) | 🔴 Pendiente |
| Alertas de stock bajo | 🔴 Pendiente |
| Historial de ventas | 🔴 Pendiente |
| Reportes básicos de ventas | 🔴 Pendiente |

**Stack:** HTML, CSS, JavaScript, Python/Flask, SQLite, Bootstrap, Git/GitHub.

## Versión 2.0 — Expansión (Futura)

> Estas funcionalidades están **fuera del alcance del SRS v1.0** y quedan para versiones futuras.

| Funcionalidad | Motivo de postergación |
|---------------|------------------------|
| Facturación electrónica (DIAN) | Complejidad regulatoria fuera del alcance junior |
| Integración con pasarelas de pago bancario | Requiere contratos y credenciales bancarias |
| Aplicación móvil (Android/iOS) | Requiere stack adicional no definido |
| Gestión avanzada de proveedores | Fuera del problema principal identificado |
| Soporte para múltiples sucursales | El negocio tiene una sola sede actualmente |

## Referencias

- SRS La Esquina v1.0 — Sección "Alcance del Sistema": Funciones Incluidas y Funciones Fuera del Alcance.
