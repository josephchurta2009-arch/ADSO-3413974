# Product Backlog

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Lista priorizada de funcionalidades a desarrollar para la versión 1.0, derivada directamente de los requerimientos funcionales del SRS.

## Backlog v1.0 — Priorizado

| # | Funcionalidad | RF origen | Actor | Prioridad | Estado |
|---|---------------|-----------|-------|-----------|--------|
| 1 | Autenticación: inicio de sesión con usuario y contraseña | RF-01 | Ambos | 🔴 Alta | Pendiente |
| 2 | Gestión de productos: agregar, editar y eliminar | RF-05 | Administrador | 🔴 Alta | Pendiente |
| 3 | Registro de ventas por el cajero | RF-02 | Cajero | 🔴 Alta | Pendiente |
| 4 | Cálculo automático del total de la venta | RF-03 | Sistema | 🔴 Alta | Pendiente |
| 5 | Actualización automática del inventario tras venta | RF-04 | Sistema | 🔴 Alta | Pendiente |
| 6 | Almacenamiento del historial de ventas | RF-08 | Sistema | 🟡 Media | Pendiente |
| 7 | Alertas de stock bajo | RF-06 | Sistema → Admin | 🟡 Media | Pendiente |
| 8 | Reportes básicos de ventas (por día y por fecha) | RF-07 | Administrador | 🟡 Media | Pendiente |

## Leyenda de prioridad

| Prioridad | Significado |
|-----------|-------------|
| 🔴 Alta | Funcionalidad core sin la cual el sistema no cumple su propósito mínimo |
| 🟡 Media | Funcionalidad importante pero que puede entregarse en una segunda iteración |
| 🟢 Baja | Mejora o nice-to-have para versiones futuras |

## Referencias

- SRS La Esquina v1.0 — Tabla 3 (Requerimientos Funcionales RF-01 a RF-08).
