# Requerimientos Funcionales

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contexto

Los requerimientos funcionales describen las capacidades y comportamientos que el sistema debe proveer. Tomados directamente del SRS versión 1.0, Tabla 3.

## Requerimientos funcionales — v1.0

| ID | Requerimiento | Actor | Módulo |
|----|---------------|-------|--------|
| RF-01 | El sistema debe permitir iniciar sesión con usuario y contraseña. | Todos | Autenticación |
| RF-02 | El cajero debe poder registrar ventas. | Cajero | Ventas |
| RF-03 | El sistema debe calcular automáticamente el total de la venta. | Sistema | Ventas |
| RF-04 | El sistema debe actualizar el inventario después de cada venta. | Sistema | Inventario |
| RF-05 | El administrador debe poder agregar, editar y eliminar productos. | Administrador | Productos |
| RF-06 | El sistema debe mostrar alertas de stock bajo. | Sistema | Inventario |
| RF-07 | El administrador debe poder consultar reportes básicos de ventas. | Administrador | Reportes |
| RF-08 | El sistema debe guardar el historial de ventas. | Sistema | Ventas |

## Descripción detallada

### RF-01 — Autenticación

- **Descripción:** El sistema presenta un formulario de inicio de sesión con campos de usuario y contraseña. Solo los usuarios registrados con credenciales válidas pueden acceder.
- **Precondición:** El usuario existe en la base de datos con contraseña almacenada como hash.
- **Postcondición:** El usuario accede a los módulos correspondientes a su rol.
- **Actor principal:** Administrador y Cajero.

### RF-02 — Registrar venta

- **Descripción:** El cajero selecciona productos por nombre o código, define la cantidad y confirma la venta.
- **Precondición:** El cajero tiene sesión activa. Los productos tienen stock disponible.
- **Postcondición:** La venta queda registrada en el historial. El inventario se actualiza (RF-04). El total es calculado (RF-03).
- **Actor principal:** Cajero.

### RF-03 — Cálculo automático del total

- **Descripción:** Al registrar cada ítem de venta, el sistema calcula en tiempo real el subtotal y el total acumulado de la venta.
- **Fórmula:** `Total = Σ (precio_unitario × cantidad)` por cada ítem.
- **Actor principal:** Sistema (automático).

### RF-04 — Actualizar inventario tras venta

- **Descripción:** Una vez confirmada la venta, el stock de cada producto incluido se reduce en la cantidad vendida.
- **Validación:** Si el stock resultante es igual o menor al stock mínimo, se dispara RF-06.
- **Actor principal:** Sistema (automático).

### RF-05 — Gestión de productos

- **Descripción:** El administrador puede crear nuevos productos, modificar sus datos (nombre, precio, stock mínimo) y eliminarlos del catálogo.
- **Precondición:** El usuario tiene rol de Administrador.
- **Actor principal:** Administrador.

### RF-06 — Alertas de stock bajo

- **Descripción:** Cuando el stock de un producto es igual o inferior al stock mínimo definido, el sistema muestra una alerta visible en la interfaz del administrador.
- **Actor principal:** Sistema → Administrador.

### RF-07 — Reportes de ventas

- **Descripción:** El administrador puede consultar un reporte que muestre las ventas realizadas en un día específico o en un rango de fechas.
- **Precondición:** Existen ventas registradas en el historial.
- **Actor principal:** Administrador.

### RF-08 — Historial de ventas

- **Descripción:** Cada venta confirmada se almacena permanentemente en la base de datos con fecha, hora, cajero, productos, cantidades y total.
- **Restricción:** El historial es de solo lectura; no se pueden eliminar ventas registradas.
- **Actor principal:** Sistema (automático).

## Referencias

- SRS La Esquina v1.0 — Tabla 3: Requerimientos Funcionales del Sistema.
