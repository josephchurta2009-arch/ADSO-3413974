# Matriz de Trazabilidad

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Relaciona los requerimientos funcionales del SRS con las historias de usuario, los casos de uso y los requerimientos no funcionales que aplican a cada uno.

## Matriz RF → HU → CU → RNF

| ID RF | Descripción RF | Historia de Usuario | Caso de Uso | RNF que aplica |
|-------|---------------|---------------------|-------------|----------------|
| RF-01 | Inicio de sesión con usuario y contraseña | HU-01 | — | RNF-04, RNF-05 |
| RF-02 | Cajero registra ventas | HU-02 | CU-01 | RNF-01, RNF-02, RNF-04 |
| RF-03 | Cálculo automático del total | HU-02 | CU-01 | RNF-02 |
| RF-04 | Actualización del inventario tras venta | HU-02 | CU-01 | RNF-02 |
| RF-05 | Gestión de productos (CRUD) | HU-03 | CU-02 | RNF-01, RNF-04, RNF-05 |
| RF-06 | Alertas de stock bajo | HU-04 | — | RNF-02, RNF-04 |
| RF-07 | Reportes básicos de ventas | HU-05 | CU-03 | RNF-02, RNF-04, RNF-05 |
| RF-08 | Historial de ventas | HU-06 | — | RNF-02, RNF-05 |

## Cobertura de RNF por módulo

| Módulo | RNF-01 | RNF-02 | RNF-03 | RNF-04 | RNF-05 |
|--------|:------:|:------:|:------:|:------:|:------:|
| Autenticación | ✅ | ✅ | ✅ | ✅ | ✅ |
| Ventas | ✅ | ✅ | ✅ | ✅ | ✅ |
| Inventario | ✅ | ✅ | ✅ | ✅ | ✅ |
| Productos | ✅ | ✅ | ✅ | ✅ | ✅ |
| Reportes | ✅ | ✅ | ✅ | ✅ | ✅ |

## Cobertura de Casos de Uso

| Caso de Uso | Actor | RF que soporta | HU relacionada |
|-------------|-------|----------------|----------------|
| CU-01: Registrar Venta | Cajero | RF-02, RF-03, RF-04, RF-08 | HU-02 |
| CU-02: Gestionar Productos | Administrador | RF-05 | HU-03 |
| CU-03: Consultar Reportes | Administrador | RF-07 | HU-05 |

## Referencias

- SRS La Esquina v1.0 — Tabla 3 (RF), Tabla 4 (RNF), Casos de Uso CU-01 a CU-03.
- [functional.md](./functional.md) — Detalle de requerimientos funcionales.
- [non-functional.md](./non-functional.md) — Detalle de requerimientos no funcionales.
- [user-stories.md](./user-stories.md) — Historias de usuario.
