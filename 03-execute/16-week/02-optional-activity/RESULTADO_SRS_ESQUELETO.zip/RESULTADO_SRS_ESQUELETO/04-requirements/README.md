# Requisitos

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contenido

Centraliza los requerimientos funcionales, no funcionales, historias de usuario y la matriz de trazabilidad del sistema de gestión del supermercado "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [functional.md](./functional.md) | Requerimientos funcionales RF-01 a RF-08 | 🟢 |
| [non-functional.md](./non-functional.md) | Requerimientos no funcionales RNF-01 a RNF-05 | 🟢 |
| [user-stories.md](./user-stories.md) | Historias de usuario y criterios de aceptación | 🟢 |
| [traceability-matrix.md](./traceability-matrix.md) | Relación entre requerimientos, historias y casos de uso | 🟢 |
