# Requerimientos No Funcionales

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contexto

Los requerimientos no funcionales establecen las restricciones de calidad bajo las cuales el sistema debe operar. Tomados directamente del SRS versión 1.0, Tabla 4.

## Requerimientos no funcionales — v1.0

| ID | Requerimiento | Categoría | Criterio de medición |
|----|---------------|-----------|----------------------|
| RNF-01 | El sistema debe ser fácil de usar. | Usabilidad | Un usuario sin capacitación previa puede registrar una venta en menos de 5 minutos |
| RNF-02 | El tiempo de respuesta debe ser menor a 2 segundos. | Rendimiento | Todas las operaciones responden en ≤ 2 s bajo condiciones normales |
| RNF-03 | El sistema debe funcionar en computadores básicos del negocio. | Compatibilidad | Funcional en equipos con 4 GB RAM, navegador Chrome/Firefox actualizado |
| RNF-04 | La interfaz debe estar en español. | Internacionalización | Todos los textos, mensajes de error y etiquetas en idioma español |
| RNF-05 | Solo usuarios autorizados podrán acceder al sistema. | Seguridad | Sin sesión activa válida, el sistema redirige al login; cada rol ve solo sus módulos |

## Descripción detallada

### RNF-01 — Usabilidad

- La interfaz usa Bootstrap para garantizar un diseño limpio y consistente.
- Los flujos de trabajo principales (registrar venta, gestionar productos) deben ser completables sin consultar un manual.
- Los mensajes de error deben ser claros y descriptivos.

### RNF-02 — Rendimiento

- Aplica a todas las operaciones: carga de módulos, registro de venta, actualización de inventario, generación de reportes.
- Medido en red local o conexión estándar de uso del negocio.
- El backend en Flask con SQLite debe ser capaz de responder en este tiempo para el volumen esperado de un negocio pequeño.

### RNF-03 — Compatibilidad

- No requiere instalación de software adicional por parte del usuario final (solo un navegador web).
- Compatible con computadores de gama básica típicos en pequeños negocios de barrio en Colombia.
- El sistema web debe ser responsive o al menos funcional en resoluciones estándar de escritorio.

### RNF-04 — Idioma

- Todos los elementos de UI: botones, etiquetas, mensajes, alertas, títulos y reportes en español.
- Mensajes de error descriptivos en español (ej: "Stock insuficiente", "Usuario o contraseña incorrectos").

### RNF-05 — Seguridad

- Rutas protegidas por sesión: cualquier intento de acceso sin autenticación redirige al login.
- Los módulos de gestión de productos, inventario y reportes solo son accesibles para el rol Administrador.
- El módulo de ventas es accesible para ambos roles (Administrador y Cajero).

## Referencias

- SRS La Esquina v1.0 — Tabla 4: Requerimientos No Funcionales del Sistema.
