# Historias de Usuario

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Historias de usuario derivadas de los requerimientos funcionales del SRS v1.0 y de los casos de uso CU-01 a CU-03. Cada historia sigue el formato estándar: **Como** [rol], **quiero** [acción], **para** [beneficio].

---

## HU-01 — Iniciar sesión en el sistema

**Como** usuario del sistema (administrador o cajero),  
**quiero** ingresar mi usuario y contraseña para acceder al sistema,  
**para** garantizar que solo personas autorizadas usen la aplicación.

**Criterios de aceptación:**
- [ ] El formulario de login tiene campos de usuario y contraseña.
- [ ] Con credenciales correctas, el sistema redirige al panel del rol correspondiente.
- [ ] Con credenciales incorrectas, se muestra un mensaje de error en español.
- [ ] Sin sesión activa no se puede acceder a ningún módulo protegido.

**RF relacionado:** RF-01 | **RNF relacionado:** RNF-04, RNF-05

---

## HU-02 — Registrar una venta

**Como** cajero,  
**quiero** buscar productos por nombre o código, seleccionar la cantidad y confirmar la venta,  
**para** registrar digitalmente las ventas sin usar papel ni calculadora.

**Criterios de aceptación:**
- [ ] El cajero puede buscar un producto por nombre o código.
- [ ] Al seleccionar cantidad, el subtotal se calcula automáticamente.
- [ ] El total acumulado de la venta se muestra en tiempo real.
- [ ] Al confirmar, la venta queda registrada en el historial.
- [ ] El inventario de cada producto vendido se actualiza automáticamente.
- [ ] Si no hay stock suficiente, el sistema muestra un mensaje de error.

**RF relacionado:** RF-02, RF-03, RF-04, RF-08 | **CU relacionado:** CU-01

---

## HU-03 — Gestionar productos del catálogo

**Como** administrador,  
**quiero** agregar, editar y eliminar productos del catálogo,  
**para** mantener actualizada la información de precios y disponibilidad.

**Criterios de aceptación:**
- [ ] El administrador puede agregar un producto con nombre, código, precio y stock mínimo.
- [ ] El administrador puede editar los datos de un producto existente.
- [ ] El administrador puede eliminar un producto del catálogo.
- [ ] Solo usuarios con rol Administrador pueden acceder a este módulo.

**RF relacionado:** RF-05 | **CU relacionado:** CU-02

---

## HU-04 — Ver alertas de stock bajo

**Como** administrador,  
**quiero** recibir alertas cuando el stock de un producto sea bajo,  
**para** poder reponer el inventario antes de que el producto se agote.

**Criterios de aceptación:**
- [ ] El sistema identifica automáticamente los productos con stock ≤ stock mínimo.
- [ ] La alerta es visible en la interfaz del administrador (notificación o sección de alertas).
- [ ] La alerta especifica el nombre del producto y su stock actual.

**RF relacionado:** RF-06

---

## HU-05 — Consultar reportes de ventas

**Como** administrador,  
**quiero** consultar un reporte de las ventas realizadas por día o por rango de fechas,  
**para** tomar decisiones informadas sobre el desempeño del negocio.

**Criterios de aceptación:**
- [ ] El administrador puede filtrar las ventas por fecha (día específico).
- [ ] El reporte muestra: número de ventas, productos vendidos y total recaudado.
- [ ] El reporte responde en menos de 2 segundos.
- [ ] Solo el Administrador puede acceder a este módulo.

**RF relacionado:** RF-07 | **CU relacionado:** CU-03

---

## HU-06 — Consultar historial de ventas

**Como** administrador,  
**quiero** ver el historial completo de ventas registradas,  
**para** auditar operaciones pasadas y verificar el trabajo del cajero.

**Criterios de aceptación:**
- [ ] El historial muestra todas las ventas con: fecha, hora, cajero, productos y total.
- [ ] El historial es de solo lectura (no se pueden eliminar registros).
- [ ] Las ventas están ordenadas de más reciente a más antigua.

**RF relacionado:** RF-08

## Referencias

- SRS La Esquina v1.0 — Tabla 3 (RF-01 a RF-08), Tabla 2 (Perfiles), Casos de Uso CU-01 a CU-03.
