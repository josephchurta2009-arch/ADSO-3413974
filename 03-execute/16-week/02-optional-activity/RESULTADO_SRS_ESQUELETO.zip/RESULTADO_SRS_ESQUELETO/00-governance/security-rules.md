# Reglas de seguridad

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El SRS define que solo usuarios autorizados podrán acceder al sistema (RNF-05). El sistema contempla autenticación con usuario y contraseña (RF-01) y dos roles diferenciados: **Administrador** y **Cajero**.

## Contenido

### Reglas de autenticación

- El acceso al sistema requiere usuario y contraseña válidos (RF-01).
- No publicar credenciales en el repositorio.
- Las contraseñas deben almacenarse con hash (nunca en texto plano).
- Las sesiones deben tener tiempo de expiración.

### Reglas de autorización por rol

| Recurso | Administrador | Cajero |
|---------|:---:|:---:|
| Registrar ventas | ✅ | ✅ |
| Gestionar productos | ✅ | ❌ |
| Consultar reportes | ✅ | ❌ |
| Administrar usuarios | ✅ | ❌ |
| Ver alertas de stock | ✅ | ❌ |

### Reglas de repositorio

- No subir archivos `.env` ni configuraciones con credenciales.
- No incluir datos reales de clientes o ventas en el código fuente.
- Toda variable sensible debe ir en variables de entorno.

## Referencias

- SRS La Esquina v1.0 — RNF-05, RF-01, Tabla 2 (Perfiles de Usuario)
