# Reglas de documentación

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Reglas de documentación aplicadas al proyecto **Sistema de Gestión Supermercado "La Esquina"** — versión 1.0. El SRS fue elaborado siguiendo las normas APA por estudiantes del programa ADSO del SENA, Neiva, Huila.

## Contenido

### Naming de archivos

- Usar `kebab-case.md` para todos los documentos.
- Usar nombres descriptivos: `functional.md`, `user-stories.md`, `data-dictionary.md`.
- No usar espacios, `snake_case`, `PascalCase` ni nombres genéricos.

### Carpetas

- Las carpetas raíz usan prefijo numérico: `NN-nombre`.
- Toda carpeta nueva debe tener `README.md`.

### Estructura mínima de cada documento

```markdown
# Título descriptivo

> Estado: 🔴 Pendiente | Última actualización: YYYY-MM-DD
> Autor: Nombre | Equipo: <equipo>

## Contexto

## Contenido

## Referencias
```

### Estados

| Estado | Uso |
|--------|-----|
| 🔴 Pendiente | Archivo creado, sin contenido validado |
| 🟡 En progreso | Contenido parcial o en revisión |
| 🟢 Estable | Revisado, aprobado y vigente |
| ⚫ Deprecado | Ya no aplica |

## Referencias

- SRS Sistema de Gestión Supermercado "La Esquina" v1.0 (2025)
