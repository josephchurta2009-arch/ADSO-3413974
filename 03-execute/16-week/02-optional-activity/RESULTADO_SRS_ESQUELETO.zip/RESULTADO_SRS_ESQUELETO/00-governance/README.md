# Gobierno documental

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Juan Miguel Muñoz, Nicolás Aldana, Miguel Estrada, Joseph Aguirre, Juan José Horta | Equipo: ADSO SENA

## Contenido

Reglas adoptadas por el equipo de desarrollo del sistema de gestión del supermercado "La Esquina" para documentar con criterio uniforme, sin duplicar información ni publicar datos sensibles.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [documentation-rules.md](./documentation-rules.md) | Naming, estructura mínima, estados, índices y diagramas | 🟢 |
| [git-conventions.md](./git-conventions.md) | Ramas, ambientes, releases y commits | 🟢 |
| [security-rules.md](./security-rules.md) | Reglas contra fugas de información sensible | 🟢 |
| [definition-of-ready.md](./definition-of-ready.md) | Criterios para que un documento pase a revisión | 🟢 |
| [definition-of-done.md](./definition-of-done.md) | Criterios para cerrar un documento como estable | 🟢 |
