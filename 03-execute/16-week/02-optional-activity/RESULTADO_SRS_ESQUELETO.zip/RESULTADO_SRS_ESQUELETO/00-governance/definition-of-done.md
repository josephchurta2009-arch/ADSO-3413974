# Definition of Done

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Un requerimiento o historia de usuario se considera **terminado** cuando cumple todos los criterios de esta lista.

## Criterios

- [ ] El código fue revisado por al menos un compañero (code review).
- [ ] La funcionalidad responde en menos de 2 segundos (RNF-02).
- [ ] La interfaz está en español (RNF-04).
- [ ] Solo los usuarios con el rol correcto pueden acceder a la función (RNF-05).
- [ ] Se probó manualmente el flujo completo del caso de uso.
- [ ] El inventario se actualiza correctamente si aplica (RF-04).
- [ ] No hay errores de consola ni excepciones sin manejar.
- [ ] El documento asociado en este repositorio fue actualizado a 🟢 Estable.

## Referencias

- SRS La Esquina v1.0 — RNF-01 a RNF-05, RF-01 a RF-08
