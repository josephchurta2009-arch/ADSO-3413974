# Convenciones Git

> Estado: 🟡 En progreso | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

El proyecto usa **Git y GitHub** como sistema de control de versiones (tal como se define en el SRS, Tabla 1 — Pila Tecnológica).

## Contenido

### Ramas principales

| Rama | Propósito |
|------|-----------|
| `main` | Código estable y aprobado |
| `develop` | Integración continua del equipo |
| `feature/<nombre>` | Nuevas funcionalidades |
| `fix/<nombre>` | Correcciones de errores |

### Convención de commits

```
<tipo>(<alcance>): <descripción breve>

Tipos: feat | fix | docs | refactor | test | chore
```

**Ejemplos:**
- `feat(ventas): agregar registro de venta con cálculo automático`
- `fix(inventario): corregir actualización de stock post-venta`
- `docs(srs): agregar casos de uso CU-01 a CU-03`

### Flujo de trabajo

1. Crear rama desde `develop`.
2. Desarrollar la funcionalidad.
3. Abrir Pull Request hacia `develop`.
4. Revisión de al menos un compañero.
5. Merge tras aprobación.

## Referencias

- SRS La Esquina v1.0 — Sección Tecnologías del Proyecto
