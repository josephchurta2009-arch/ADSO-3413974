# Definition of Ready

> Estado: 🟢 Estable | Última actualización: 2026-07-07
> Autor: Equipo La Esquina | Equipo: ADSO SENA

## Contexto

Un ítem de trabajo (historia de usuario, requerimiento, tarea) está listo para comenzar su desarrollo cuando cumple todos los criterios de esta lista.

## Criterios

- [ ] El requerimiento está descrito en `04-requirements/functional.md` o `user-stories.md`.
- [ ] Tiene un ID asignado (RF-XX o HU-XX).
- [ ] El alcance es claro: qué hace y qué NO hace.
- [ ] Los criterios de aceptación están definidos.
- [ ] Se conoce el actor/usuario responsable (Administrador o Cajero).
- [ ] No tiene dependencias bloqueantes sin resolver.
- [ ] Fue revisado por al menos un miembro del equipo distinto al autor.

## Referencias

- SRS La Esquina v1.0 — Sección Requerimientos Funcionales y No Funcionales
